"""Research-grade simulation utilities for robust decentralized cell-free ISAC.

This module extends the SplitOpt/JointOpt setting of Zafari et al. with:
1) a strict separation between the true channel and estimated CSI,
2) probabilistic norm-bounded CSI uncertainty sets,
3) user-specific uncertainty-aware AP responsibility weights eta[a,u],
4) a robust SCA-consensus-ADMM beamforming routine,
5) evaluation on the true channel, Monte-Carlo summaries, confidence intervals,
6) an optional centralized robust SOCP benchmark.

The code is intended for reproducible research. It does not guarantee publication
or global optimality. The SCA-ADMM method converges to a stationary/local solution
when its numerical assumptions are met.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict, replace
from pathlib import Path
from typing import Dict, Iterable, List, Literal, Optional, Sequence, Tuple
import json
import math
import time
import warnings

import numpy as np
import pandas as pd

try:
    import cvxpy as cp
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "cvxpy is required. Install with: pip install cvxpy clarabel pandas scipy matplotlib"
    ) from exc

try:
    from scipy.stats import chi2
except ImportError as exc:  # pragma: no cover
    raise ImportError("scipy is required. Install with: pip install scipy") from exc


Array = np.ndarray
EtaMode = Literal["uniform", "gain", "uncertainty_aware"]


@dataclass(frozen=True)
class SystemConfig:
    # Network
    n_ap: int = 7
    n_users: int = 4
    n_ant: int = 4
    n_targets: int = 1
    p_max_w: float = 1.0
    nominal_tx_snr_db: float = 20.0
    tx_fraction_init: float = 0.80

    # Geometry
    env_radius_m: float = 1000.0
    ap_radius_m: float = 650.0
    h_ap_m: float = 10.0
    h_ue_m: float = 1.5
    h_target_m: float = 0.5

    # RF / noise
    fc_hz: float = 3.5e9
    bandwidth_hz: float = 20e6
    noise_figure_db: float = 7.0
    temperature_k: float = 290.0

    # Channel / UCA
    shadow_los_db: float = 4.0
    shadow_nlos_db: float = 7.82
    rician_k_los_db: float = 9.0
    uca_radius_lambda: float = 0.5

    # Sensing (relative multistatic model)
    rcs_variance: float = 0.5
    sensing_noise_variance: float = 1.0

    # Randomness
    seed: int = 2026

    @property
    def wavelength_m(self) -> float:
        return 299_792_458.0 / self.fc_hz

    @property
    def uca_radius_m(self) -> float:
        return self.uca_radius_lambda * self.wavelength_m

    @property
    def noise_power_w(self) -> float:
        # kTB times receiver noise figure
        k_b = 1.380649e-23
        return k_b * self.temperature_k * self.bandwidth_hz * 10.0 ** (
            self.noise_figure_db / 10.0
        )

    @property
    def normalized_noise_variance(self) -> float:
        return self.p_max_w / (10.0 ** (self.nominal_tx_snr_db / 10.0))

    @property
    def n_streams(self) -> int:
        return self.n_users + self.n_targets


@dataclass(frozen=True)
class ADMMConfig:
    lambda_comm: float = 0.90
    rho: float = 2.0
    slack_penalty: float = 5_000.0
    proximal_weight: float = 10.0
    max_iters: int = 50
    min_iters: int = 6
    abs_tol: float = 1e-3
    rel_tol: float = 1e-3
    gamma_cap_linear: float = 1e3
    solver: str = "CLARABEL"
    solver_max_iters: int = 5_000
    verbose_solver: bool = False


@dataclass
class Scenario:
    ap_xy: Array  # (A,2)
    ue_xy: Array  # (U,2)
    target_xy: Array  # (T,2)
    rx_ap: int
    tx_aps: Array
    h_true: Array  # noise-whitened, (U,M,A)
    target_steering: Array  # (T,M,A)
    target_derivative: Array  # (T,M,A), derivative w.r.t. azimuth radians
    zeta2: Array  # (T,A)
    noise_power_w: float
    normalized_noise_variance: float
    channel_scale: float


@dataclass
class CSIRealization:
    h_hat: Array
    error: Array
    epsilon: Array  # (U,A) norm-ball radius in normalized channel units
    error_variance: Array  # (U,A), per-complex-entry variance
    pilot_snr_db: float
    confidence: float
    pilot_length: int = 1
    estimator: str = "ls"


@dataclass
class OptimizationResult:
    W: Array
    gamma_consensus: float
    gamma_local: Array
    history: pd.DataFrame
    status: str
    runtime_s: float
    eta: Array
    epsilon: Array


# ---------------------------------------------------------------------------
# Geometry and physical channel generation
# ---------------------------------------------------------------------------

def _rng(seed: int) -> np.random.Generator:
    return np.random.default_rng(int(seed))


def generate_positions(cfg: SystemConfig, rng: np.random.Generator) -> Tuple[Array, Array, Array]:
    ap_angles = np.linspace(0.0, 2.0 * np.pi, cfg.n_ap, endpoint=False)
    ap_xy = np.column_stack(
        [cfg.ap_radius_m * np.cos(ap_angles), cfg.ap_radius_m * np.sin(ap_angles)]
    )

    def sample_disc(n: int, radius: float) -> Array:
        r = radius * np.sqrt(rng.uniform(0.0, 1.0, size=n))
        a = rng.uniform(0.0, 2.0 * np.pi, size=n)
        return np.column_stack([r * np.cos(a), r * np.sin(a)])

    ue_xy = sample_disc(cfg.n_users, 0.90 * cfg.env_radius_m)
    target_xy = sample_disc(cfg.n_targets, 0.75 * cfg.env_radius_m)
    return ap_xy, ue_xy, target_xy


def uca_response(
    n_ant: int,
    radius_m: float,
    wavelength_m: float,
    azimuth_rad: float,
    elevation_rad: float = np.pi / 2.0,
    normalize: bool = True,
) -> Array:
    element_angles = 2.0 * np.pi * np.arange(n_ant) / n_ant
    phase = (
        2.0
        * np.pi
        / wavelength_m
        * radius_m
        * np.sin(elevation_rad)
        * np.cos(azimuth_rad - element_angles)
    )
    a = np.exp(1j * phase)
    if normalize:
        a = a / np.sqrt(n_ant)
    return a


def uca_azimuth_derivative(
    n_ant: int,
    radius_m: float,
    wavelength_m: float,
    azimuth_rad: float,
    elevation_rad: float = np.pi / 2.0,
    normalize: bool = True,
) -> Array:
    element_angles = 2.0 * np.pi * np.arange(n_ant) / n_ant
    a = uca_response(
        n_ant, radius_m, wavelength_m, azimuth_rad, elevation_rad, normalize=False
    )
    dphase_daz = (
        2.0
        * np.pi
        / wavelength_m
        * radius_m
        * np.sin(elevation_rad)
        * np.sin(azimuth_rad - element_angles)
    )
    da = 1j * dphase_daz * a
    if normalize:
        da = da / np.sqrt(n_ant)
    return da


def _umi_los_probability(d2d_m: float) -> float:
    d = max(float(d2d_m), 1.0)
    return min(18.0 / d, 1.0) * (1.0 - np.exp(-d / 36.0)) + np.exp(-d / 36.0)


def _umi_pathloss_db(
    d2d_m: float,
    d3d_m: float,
    fc_ghz: float,
    h_ue_m: float,
    is_los: bool,
) -> float:
    """3GPP TR 38.901-inspired UMi street-canyon path loss.

    This implements the commonly used single-slope expressions. For strict
    standards replication, replace this helper with the exact scenario and
    breakpoint equations required by the target paper.
    """
    d3 = max(float(d3d_m), 10.0)
    pl_los = 32.4 + 21.0 * np.log10(d3) + 20.0 * np.log10(fc_ghz)
    if is_los:
        return float(pl_los)
    pl_nlos = (
        22.4
        + 35.3 * np.log10(d3)
        + 21.3 * np.log10(fc_ghz)
        - 0.3 * (h_ue_m - 1.5)
    )
    return float(max(pl_los, pl_nlos))


def generate_true_scenario(cfg: SystemConfig, seed: Optional[int] = None) -> Scenario:
    rng = _rng(cfg.seed if seed is None else seed)
    ap_xy, ue_xy, target_xy = generate_positions(cfg, rng)

    # Closest AP to first target is the receive AP, following the base-paper setup.
    rx_ap = int(np.argmin(np.linalg.norm(ap_xy - target_xy[0], axis=1)))
    tx_aps = np.array([a for a in range(cfg.n_ap) if a != rx_ap], dtype=int)

    h_physical = np.zeros((cfg.n_users, cfg.n_ant, cfg.n_ap), dtype=np.complex128)
    fc_ghz = cfg.fc_hz / 1e9
    k_los = 10.0 ** (cfg.rician_k_los_db / 10.0)

    for u in range(cfg.n_users):
        for a in tx_aps:
            delta = ue_xy[u] - ap_xy[a]
            d2d = float(np.linalg.norm(delta))
            d3d = float(np.sqrt(d2d**2 + (cfg.h_ap_m - cfg.h_ue_m) ** 2))
            is_los = bool(rng.uniform() < _umi_los_probability(d2d))
            pl_db = _umi_pathloss_db(d2d, d3d, fc_ghz, cfg.h_ue_m, is_los)
            shadow_std = cfg.shadow_los_db if is_los else cfg.shadow_nlos_db
            pl_db += float(rng.normal(0.0, shadow_std))
            beta = 10.0 ** (-pl_db / 10.0)

            az = float(np.arctan2(delta[1], delta[0]))
            a_los = uca_response(
                cfg.n_ant,
                cfg.uca_radius_m,
                cfg.wavelength_m,
                az,
                normalize=True,
            )
            g = (rng.standard_normal(cfg.n_ant) + 1j * rng.standard_normal(cfg.n_ant)) / np.sqrt(
                2.0 * cfg.n_ant
            )
            if is_los:
                small_scale = np.sqrt(k_los / (k_los + 1.0)) * a_los + np.sqrt(
                    1.0 / (k_los + 1.0)
                ) * g
            else:
                small_scale = g
            h_physical[u, :, a] = np.sqrt(beta) * small_scale

    # Normalize the median AP-user channel norm to one while preserving all
    # relative path-loss and fading differences. The normalized noise variance
    # then enforces the base-paper-style Pmax/sigma^2 operating point.
    link_norms = [
        np.linalg.norm(h_physical[u, :, a])
        for u in range(cfg.n_users)
        for a in tx_aps
        if np.linalg.norm(h_physical[u, :, a]) > 0
    ]
    median_norm = float(np.median(link_norms)) if link_norms else 1.0
    channel_scale = 1.0 / max(median_norm, 1e-30)
    h_true = h_physical * channel_scale

    target_steering = np.zeros(
        (cfg.n_targets, cfg.n_ant, cfg.n_ap), dtype=np.complex128
    )
    target_derivative = np.zeros_like(target_steering)
    zeta2 = np.zeros((cfg.n_targets, cfg.n_ap), dtype=float)

    for t in range(cfg.n_targets):
        d_rx = max(float(np.linalg.norm(target_xy[t] - ap_xy[rx_ap])), 1.0)
        raw_gains: List[float] = []
        for a in range(cfg.n_ap):
            if a == rx_ap:
                raw_gains.append(0.0)
                continue
            delta = target_xy[t] - ap_xy[a]
            d_tx = max(float(np.linalg.norm(delta)), 1.0)
            az = float(np.arctan2(delta[1], delta[0]))
            target_steering[t, :, a] = uca_response(
                cfg.n_ant,
                cfg.uca_radius_m,
                cfg.wavelength_m,
                az,
                normalize=True,
            )
            target_derivative[t, :, a] = uca_azimuth_derivative(
                cfg.n_ant,
                cfg.uca_radius_m,
                cfg.wavelength_m,
                az,
                normalize=True,
            )
            # Relative bistatic path gain. Normalized below to avoid numerical underflow.
            raw_gains.append(1.0 / (d_tx**2 * d_rx**2))
        raw = np.asarray(raw_gains)
        positive = raw[raw > 0]
        norm = np.median(positive) if positive.size else 1.0
        zeta2[t] = cfg.rcs_variance * raw / max(norm, 1e-30)

    return Scenario(
        ap_xy=ap_xy,
        ue_xy=ue_xy,
        target_xy=target_xy,
        rx_ap=rx_ap,
        tx_aps=tx_aps,
        h_true=h_true,
        target_steering=target_steering,
        target_derivative=target_derivative,
        zeta2=zeta2,
        noise_power_w=cfg.noise_power_w,
        normalized_noise_variance=cfg.normalized_noise_variance,
        channel_scale=channel_scale,
    )


# ---------------------------------------------------------------------------
# CSI estimation and uncertainty sets
# ---------------------------------------------------------------------------

def estimate_csi(
    h_true: Array,
    pilot_snr_db: float,
    rx_ap: int,
    seed: int,
    confidence: float = 0.95,
    base_error: Optional[Array] = None,
    pilot_length: int = 1,
    estimator: str = "ls",
) -> CSIRealization:
    """Generate estimated CSI from an explicit uplink-pilot observation model.

    Pilot model (Reviewers 3 and 4). Each user transmits a length-``pilot_length``
    (tau_p) orthogonal uplink pilot at per-symbol pilot SNR
    ``rho_p = 10**(pilot_snr_db/10)``. Correlating the received pilot with the
    orthogonal user sequence gives a post-despreading effective SNR of
    ``tau_p * rho_p`` per AP-user link. With per-antenna channel power
    ``p_e = ||h_{u,a}||^2 / M`` (normalized channel units), the least-squares (LS)
    estimator has per-complex-entry error variance

        sigma_ls^2 = p_e / (tau_p * rho_p),

    and the linear MMSE (LMMSE) estimator applies Bayesian shrinkage
    ``h_hat = alpha * h_ls`` with ``alpha = p_e / (p_e + sigma_ls^2)`` and reduced
    per-entry error variance ``sigma_lmmse^2 = p_e*sigma_ls^2/(p_e+sigma_ls^2)``.
    The returned error covariance is ``C_{u,a} = sigma_e^2 * I_M`` and the
    norm-ball radius ``epsilon`` is the confidence quantile of ||e|| under this
    Gaussian model.

    Reproducibility note: ``pilot_length=1`` with ``estimator='ls'`` reproduces
    the earlier stylized SNR-scaled error model exactly. A valid orthogonal-pilot
    configuration for ``U`` users requires ``pilot_length >= U``; the recommended
    reporting setting is ``pilot_length = n_users`` with ``estimator='lmmse'``.
    Passing ``base_error`` enables common random numbers across pilot-SNR values.
    """
    if not 0.0 < confidence < 1.0:
        raise ValueError("confidence must be between 0 and 1")
    if pilot_length < 1:
        raise ValueError("pilot_length must be >= 1")
    estimator = estimator.lower()
    if estimator not in {"ls", "lmmse"}:
        raise ValueError("estimator must be 'ls' or 'lmmse'")
    rng = _rng(seed)
    u_count, m_ant, a_count = h_true.shape
    if base_error is None:
        base_error = (
            rng.standard_normal(h_true.shape) + 1j * rng.standard_normal(h_true.shape)
        ) / np.sqrt(2.0)
    if base_error.shape != h_true.shape:
        raise ValueError("base_error must have the same shape as h_true")

    pilot_linear = 10.0 ** (pilot_snr_db / 10.0)
    effective_pilot = max(pilot_length * pilot_linear, 1e-12)
    h_hat = np.array(h_true, dtype=np.complex128)
    error = np.zeros_like(h_true)
    epsilon = np.zeros((u_count, a_count), dtype=float)
    error_variance = np.zeros((u_count, a_count), dtype=float)
    q = float(chi2.ppf(confidence, df=2 * m_ant))

    for u in range(u_count):
        for a in range(a_count):
            if a == rx_ap:
                continue
            p_e = np.linalg.norm(h_true[u, :, a]) ** 2 / m_ant
            sigma_ls2 = p_e / effective_pilot
            ls_error = np.sqrt(sigma_ls2) * base_error[u, :, a]
            h_ls = h_true[u, :, a] + ls_error
            if estimator == "lmmse":
                alpha = p_e / max(p_e + sigma_ls2, 1e-30)
                h_est = alpha * h_ls
                sigma_e2 = p_e * sigma_ls2 / max(p_e + sigma_ls2, 1e-30)
            else:
                h_est = h_ls
                sigma_e2 = sigma_ls2
            h_hat[u, :, a] = h_est
            error[u, :, a] = h_est - h_true[u, :, a]
            epsilon[u, a] = np.sqrt(0.5 * sigma_e2 * q)
            error_variance[u, a] = sigma_e2

    return CSIRealization(
        h_hat=h_hat,
        error=error,
        epsilon=epsilon,
        error_variance=error_variance,
        pilot_snr_db=float(pilot_snr_db),
        confidence=float(confidence),
        pilot_length=int(pilot_length),
        estimator=estimator,
    )


def sample_csi_scenarios(
    csi: CSIRealization,
    n_scenarios: int,
    seed: int,
    include_nominal: bool = True,
) -> Array:
    """Draw candidate true channels around the estimate for scenario optimization.

    Because the complex Gaussian estimation error is symmetric, candidate true
    channels can be represented as h_hat + e_s with the same covariance. The
    first sample may be the nominal estimate to stabilize optimization.
    """
    if n_scenarios < 1:
        raise ValueError("n_scenarios must be >= 1")
    rng = _rng(seed)
    samples = np.empty((n_scenarios,) + csi.h_hat.shape, dtype=np.complex128)
    start = 0
    if include_nominal:
        samples[0] = csi.h_hat
        start = 1
    for k in range(start, n_scenarios):
        z = (
            rng.standard_normal(csi.h_hat.shape)
            + 1j * rng.standard_normal(csi.h_hat.shape)
        ) / np.sqrt(2.0)
        scale = np.sqrt(csi.error_variance)[:, None, :]
        samples[k] = csi.h_hat + scale * z
    return samples


# ---------------------------------------------------------------------------
# Beamforming initialization and AP-user responsibility weights
# ---------------------------------------------------------------------------

def _project_to_ap_power(Wa: Array, pmax: float) -> Array:
    norm = np.linalg.norm(Wa, "fro")
    if norm <= np.sqrt(pmax) or norm == 0.0:
        return Wa
    return Wa * (np.sqrt(pmax) / norm)


def initialize_rzf_nsc(
    cfg: SystemConfig,
    scenario: Scenario,
    h_design: Array,
    regularization: float = 1e-2,
) -> Array:
    """RZF communication beams plus null-space target beams.

    Unlike the flawed V5 comparison, this initializer is valid in both full-rank
    and low-rank settings because regularized least squares is used; however,
    SplitOpt claims should only be made in the full-rank regime M >= U.
    """
    W = np.zeros((cfg.n_ant, cfg.n_streams, cfg.n_ap), dtype=np.complex128)
    p_comm = cfg.tx_fraction_init * cfg.p_max_w
    p_sens = (1.0 - cfg.tx_fraction_init) * cfg.p_max_w

    for a in scenario.tx_aps:
        Ha = h_design[:, :, a]
        # RZF / regularized least-squares local communication precoder.
        gram = Ha.conj().T @ Ha
        Wc = np.linalg.solve(
            gram + regularization * np.trace(gram).real / max(cfg.n_ant, 1) * np.eye(cfg.n_ant)
            + 1e-8 * np.eye(cfg.n_ant),
            Ha.conj().T,
        )
        if np.linalg.norm(Wc, "fro") > 0:
            Wc *= np.sqrt(p_comm) / np.linalg.norm(Wc, "fro")
        W[:, : cfg.n_users, a] = Wc

        # Project each target steering vector away from the estimated user subspace.
        Hh = Ha @ Ha.conj().T
        P_perp = np.eye(cfg.n_ant) - Ha.conj().T @ np.linalg.solve(
            Hh + 1e-3 * np.trace(Hh).real / max(cfg.n_users, 1) * np.eye(cfg.n_users)
            + 1e-8 * np.eye(cfg.n_users),
            Ha,
        )
        Ws = []
        for t in range(cfg.n_targets):
            v = P_perp @ scenario.target_steering[t, :, a]
            if np.linalg.norm(v) < 1e-10:
                v = scenario.target_steering[t, :, a]
            Ws.append(v / max(np.linalg.norm(v), 1e-12))
        Ws_arr = np.column_stack(Ws)
        Ws_arr *= np.sqrt(p_sens) / max(np.linalg.norm(Ws_arr, "fro"), 1e-12)
        W[:, cfg.n_users :, a] = Ws_arr
        W[:, :, a] = _project_to_ap_power(W[:, :, a], cfg.p_max_w)
    return W


def compute_eta(
    h_hat: Array,
    epsilon: Array,
    tx_aps: Sequence[int],
    mode: EtaMode = "uncertainty_aware",
    temperature: float = 0.75,
    floor_mass: float = 0.10,
) -> Array:
    """Return user-specific eta[u,a], normalized over transmit APs per user.

    ``uncertainty_aware`` uses the conservative channel amplitude
    max(||h_hat|| - epsilon, 0), preventing uncertain AP-user links from
    receiving excessive responsibility.
    """
    u_count, _, a_count = h_hat.shape
    eta = np.zeros((u_count, a_count), dtype=float)
    tx = np.asarray(tx_aps, dtype=int)
    if not 0.0 <= floor_mass < 1.0:
        raise ValueError("floor_mass must lie in [0,1)")

    for u in range(u_count):
        if mode == "uniform":
            scores = np.ones(len(tx), dtype=float)
        else:
            gain_amp = np.array([np.linalg.norm(h_hat[u, :, a]) for a in tx])
            if mode == "gain":
                robust_amp = gain_amp
            elif mode == "uncertainty_aware":
                robust_amp = np.maximum(
                    gain_amp - np.array([epsilon[u, a] for a in tx]), 0.0
                )
            else:
                raise ValueError(f"Unknown eta mode: {mode}")
            scores = np.maximum(robust_amp**2, 1e-12) ** temperature
        scores /= max(scores.sum(), 1e-12)
        scores = (1.0 - floor_mass) * scores + floor_mass / len(tx)
        eta[u, tx] = scores / scores.sum()

    # Strong invariant: each user's responsibilities must sum to one.
    if not np.allclose(eta[:, tx].sum(axis=1), 1.0, atol=1e-8):
        raise RuntimeError("eta normalization failed")
    return eta


# ---------------------------------------------------------------------------
# Metrics -- always evaluate communication on h_true
# ---------------------------------------------------------------------------

def received_stream_matrix(h_eval: Array, W: Array, tx_aps: Sequence[int]) -> Array:
    u_count = h_eval.shape[0]
    d_count = W.shape[1]
    out = np.zeros((u_count, d_count), dtype=np.complex128)
    for a in tx_aps:
        out += h_eval[:, :, a] @ W[:, :, a]
    return out


def sinr_linear(h_eval: Array, W: Array, tx_aps: Sequence[int], noise_variance: float = 1.0) -> Array:
    Y = received_stream_matrix(h_eval, W, tx_aps)
    u_count = h_eval.shape[0]
    out = np.zeros(u_count, dtype=float)
    for u in range(u_count):
        desired = abs(Y[u, u]) ** 2
        interference = np.sum(np.abs(Y[u, :]) ** 2) - desired
        out[u] = desired / max(interference + noise_variance, 1e-15)
    return out


def sinr_db(h_eval: Array, W: Array, tx_aps: Sequence[int], noise_variance: float = 1.0) -> Array:
    return 10.0 * np.log10(np.maximum(sinr_linear(h_eval, W, tx_aps, noise_variance), 1e-15))


def sensing_snr_linear(cfg: SystemConfig, scenario: Scenario, W: Array) -> Array:
    values = np.zeros(cfg.n_targets, dtype=float)
    for t in range(cfg.n_targets):
        total = 0.0
        for a in scenario.tx_aps:
            response = scenario.target_steering[t, :, a].conj() @ W[:, :, a]
            total += scenario.zeta2[t, a] * np.linalg.norm(response) ** 2
        values[t] = cfg.n_ant * total / cfg.sensing_noise_variance
    return values


def sensing_snr_db(cfg: SystemConfig, scenario: Scenario, W: Array) -> Array:
    return 10.0 * np.log10(np.maximum(sensing_snr_linear(cfg, scenario, W), 1e-15))


def azimuth_crb_deg2(cfg: SystemConfig, scenario: Scenario, W: Array) -> Array:
    crb = np.zeros(cfg.n_targets, dtype=float)
    for t in range(cfg.n_targets):
        fim = 0.0
        for a in scenario.tx_aps:
            d = scenario.target_derivative[t, :, a]
            response = d.conj() @ W[:, :, a]
            fim += (
                2.0
                * cfg.n_ant
                * scenario.zeta2[t, a]
                * np.linalg.norm(response) ** 2
                / cfg.sensing_noise_variance
            )
        crb[t] = (180.0 / np.pi) ** 2 / max(fim, 1e-15)
    return crb


def per_ap_power(W: Array) -> Array:
    return np.sum(np.abs(W) ** 2, axis=(0, 1))


def summarize_metrics(
    cfg: SystemConfig,
    scenario: Scenario,
    W: Array,
    sinr_target_db: float = 5.0,
) -> Dict[str, float]:
    s_db = sinr_db(
        scenario.h_true, W, scenario.tx_aps, scenario.normalized_noise_variance
    )
    sens_db = sensing_snr_db(cfg, scenario, W)
    crb = azimuth_crb_deg2(cfg, scenario, W)
    powers = per_ap_power(W)
    return {
        "min_sinr_db": float(np.min(s_db)),
        "mean_sinr_db": float(np.mean(s_db)),
        "p05_sinr_db": float(np.quantile(s_db, 0.05)),
        "sinr_outage": float(np.mean(s_db < sinr_target_db)),
        "worst_target_snr_db": float(np.min(sens_db)),
        "mean_target_snr_db": float(np.mean(sens_db)),
        "worst_target_crb_deg2": float(np.max(crb)),
        "mean_target_crb_deg2": float(np.mean(crb)),
        "max_ap_power_w": float(np.max(powers[scenario.tx_aps])),
    }


# ---------------------------------------------------------------------------
# Robust local interference bound and decentralized SCA-consensus-ADMM
# ---------------------------------------------------------------------------

def _local_interference_bound(
    h_hat: Array,
    epsilon: Array,
    W: Array,
    tx_aps: Sequence[int],
) -> Array:
    """Minkowski-style global interference amplitude upper bound per user."""
    u_count = h_hat.shape[0]
    d_count = W.shape[1]
    psi = np.zeros(u_count, dtype=float)
    for u in range(u_count):
        keep = [i for i in range(d_count) if i != u]
        for a in tx_aps:
            Wa_int = W[:, keep, a]
            nominal = np.linalg.norm(h_hat[u, :, a].conj() @ Wa_int)
            uncertainty = epsilon[u, a] * np.linalg.norm(Wa_int, "fro")
            psi[u] += nominal + uncertainty
    return psi


def _solver_kwargs(config: ADMMConfig) -> Dict[str, object]:
    name = config.solver.upper()
    if name == "SCS":
        return {
            "solver": cp.SCS,
            "max_iters": config.solver_max_iters,
            "eps": 1e-5,
            "verbose": config.verbose_solver,
        }
    if name == "CLARABEL":
        return {
            "solver": cp.CLARABEL,
            "max_iter": config.solver_max_iters,
            "verbose": config.verbose_solver,
        }
    return {"solver": config.solver, "verbose": config.verbose_solver}


def robust_sca_consensus_admm(
    cfg: SystemConfig,
    scenario: Scenario,
    csi: CSIRealization,
    eta: Array,
    W_init: Array,
    admm: ADMMConfig = ADMMConfig(),
    use_uncertainty_margin: bool = True,
    evaluate_each_iteration: bool = True,
) -> OptimizationResult:
    """Robust user-specific SCA-consensus-ADMM.

    Local robust desired-power lower surrogate:
        g_bar(w;w0) - 2 epsilon ||h_hat|| ||w||^2
    where g_bar is the first-order lower approximation of |h_hat^H w|^2.

    Interference is upper-bounded by a nominal local amplitude plus
    epsilon*||W_interference||_F and summed across APs. The method is conservative
    and local/SCA-based; it is not a certificate of global optimality.
    """
    start = time.perf_counter()
    tx = np.asarray(scenario.tx_aps, dtype=int)
    n_tx = len(tx)
    if eta.shape != (cfg.n_users, cfg.n_ap):
        raise ValueError("eta must have shape (n_users, n_ap)")
    eps = csi.epsilon if use_uncertainty_margin else np.zeros_like(csi.epsilon)

    W = np.array(W_init, dtype=np.complex128, copy=True)
    gamma_local = np.full(cfg.n_ap, 1.0, dtype=float)
    dual = np.zeros(cfg.n_ap, dtype=float)
    z = 1.0
    psi = _local_interference_bound(csi.h_hat, eps, W, tx)
    rows: List[Dict[str, float]] = []
    status = "max_iters"

    for iteration in range(1, admm.max_iters + 1):
        z_previous = z
        W_previous_outer = W.copy()
        local_statuses: List[str] = []
        total_slack = 0.0

        for a in tx:
            W_prev = W[:, :, a].copy()
            Wa = cp.Variable((cfg.n_ant, cfg.n_streams), complex=True)
            gamma_a = cp.Variable(nonneg=True)
            slack = cp.Variable(cfg.n_users, nonneg=True)

            constraints = [
                cp.sum_squares(cp.abs(Wa)) <= cfg.p_max_w,
                gamma_a <= admm.gamma_cap_linear,
            ]

            for u in range(cfg.n_users):
                h = csi.h_hat[u, :, a]
                w0 = W_prev[:, u]
                s0 = np.vdot(h, w0)
                s = h.conj() @ Wa[:, u]
                g_bar = 2.0 * cp.real(np.conj(s0) * s) - float(abs(s0) ** 2)
                robust_penalty = (
                    2.0
                    * float(eps[u, a])
                    * float(np.linalg.norm(h))
                    * cp.sum_squares(cp.abs(Wa[:, u]))
                )
                rhs_scale = float(
                    eta[u, a]
                    * (psi[u] + np.sqrt(scenario.normalized_noise_variance)) ** 2
                )
                constraints.append(
                    g_bar - robust_penalty >= rhs_scale * gamma_a - slack[u]
                )

            # First-order lower surrogate of weighted sensing utility.
            sensing_surrogate = 0.0
            for t in range(cfg.n_targets):
                av = scenario.target_steering[t, :, a]
                v0 = av.conj() @ W_prev
                v = av.conj() @ Wa
                f_bar = 2.0 * cp.real(cp.sum(cp.multiply(np.conj(v0), v))) - float(
                    np.linalg.norm(v0) ** 2
                )
                sensing_surrogate += float(scenario.zeta2[t, a]) * f_bar
            sensing_surrogate /= max(cfg.n_targets, 1)

            prox = cp.sum_squares(cp.abs(Wa - W_prev))
            objective = cp.Maximize(
                admm.lambda_comm * gamma_a
                + (1.0 - admm.lambda_comm) * sensing_surrogate
                - 0.5 * admm.rho * cp.square(gamma_a - z + dual[a])
                - admm.slack_penalty * cp.sum(slack)
                - 0.5 * admm.proximal_weight * prox
            )
            problem = cp.Problem(objective, constraints)

            try:
                problem.solve(**_solver_kwargs(admm))
            except Exception as first_error:
                try:
                    problem.solve(
                        solver=cp.SCS,
                        max_iters=max(10_000, admm.solver_max_iters),
                        eps=1e-5,
                        verbose=admm.verbose_solver,
                    )
                except Exception as second_error:  # pragma: no cover
                    local_statuses.append(f"error:{type(second_error).__name__}")
                    warnings.warn(
                        f"AP {a} local solve failed: {first_error}; fallback: {second_error}"
                    )
                    continue

            local_statuses.append(str(problem.status))
            if Wa.value is None or gamma_a.value is None:
                continue
            candidate = np.asarray(Wa.value, dtype=np.complex128)
            if not np.all(np.isfinite(candidate)):
                continue
            W[:, :, a] = _project_to_ap_power(candidate, cfg.p_max_w)
            gamma_local[a] = float(max(gamma_a.value, 0.0))
            if slack.value is not None:
                total_slack += float(np.sum(np.maximum(slack.value, 0.0)))

        # Consensus ADMM updates.
        z = float(max(0.0, np.mean(gamma_local[tx] + dual[tx])))
        primal = float(np.linalg.norm(gamma_local[tx] - z))
        dual_residual = float(admm.rho * np.sqrt(n_tx) * abs(z - z_previous))
        dual[tx] += gamma_local[tx] - z

        # Update the global interference upper bound using current beamformers.
        psi = _local_interference_bound(csi.h_hat, eps, W, tx)
        beam_change = float(
            np.linalg.norm(W[:, :, tx] - W_previous_outer[:, :, tx])
            / max(np.linalg.norm(W_previous_outer[:, :, tx]), 1e-12)
        )

        row: Dict[str, float] = {
            "iteration": float(iteration),
            "gamma_consensus_linear": z,
            "gamma_consensus_db": 10.0 * np.log10(max(z, 1e-15)),
            "primal_residual": primal,
            "dual_residual": dual_residual,
            "beam_relative_change": beam_change,
            "total_slack": total_slack,
            "psi_mean": float(np.mean(psi)),
        }
        if evaluate_each_iteration:
            true_sinr = sinr_db(
                scenario.h_true, W, tx, scenario.normalized_noise_variance
            )
            row.update(
                {
                    "true_min_sinr_db": float(np.min(true_sinr)),
                    "true_mean_sinr_db": float(np.mean(true_sinr)),
                    "worst_target_snr_db": float(
                        np.min(sensing_snr_db(cfg, scenario, W))
                    ),
                }
            )
        rows.append(row)

        eps_primal = np.sqrt(n_tx) * admm.abs_tol + admm.rel_tol * max(
            np.linalg.norm(gamma_local[tx]), np.sqrt(n_tx) * abs(z)
        )
        eps_dual = np.sqrt(n_tx) * admm.abs_tol + admm.rel_tol * np.linalg.norm(
            admm.rho * dual[tx]
        )
        if (
            iteration >= admm.min_iters
            and primal <= eps_primal
            and dual_residual <= eps_dual
            and beam_change <= 5.0 * admm.rel_tol
        ):
            status = "converged"
            break

    history = pd.DataFrame(rows)
    runtime = time.perf_counter() - start
    # Preserve meaningful status details without exposing solver internals as claims.
    if any(s.startswith("error") for s in local_statuses):
        status += "_with_local_errors"
    return OptimizationResult(
        W=W,
        gamma_consensus=z,
        gamma_local=gamma_local,
        history=history,
        status=status,
        runtime_s=float(runtime),
        eta=eta,
        epsilon=eps,
    )


def scenario_sca_consensus_admm(
    cfg: SystemConfig,
    scenario: Scenario,
    csi: CSIRealization,
    eta: Array,
    W_init: Array,
    admm: ADMMConfig = ADMMConfig(),
    n_channel_scenarios: int = 6,
    scenario_seed: int = 9876,
    evaluate_each_iteration: bool = True,
) -> OptimizationResult:
    """Scenario-based chance-robust SCA-consensus-ADMM.

    Instead of one worst-case norm ball, this method imposes the local SCA SINR
    surrogate for several channel samples drawn from the CSI-error distribution.
    It is typically less conservative than deterministic norm-ball robustness.
    The method should be reported as *scenario/chance robust*, not worst-case
    robust, and its empirical outage must be measured on unseen channel errors.
    """
    start = time.perf_counter()
    tx = np.asarray(scenario.tx_aps, dtype=int)
    n_tx = len(tx)
    if eta.shape != (cfg.n_users, cfg.n_ap):
        raise ValueError("eta must have shape (n_users, n_ap)")

    h_samples = sample_csi_scenarios(
        csi, n_scenarios=n_channel_scenarios, seed=scenario_seed, include_nominal=True
    )
    zero_eps = np.zeros_like(csi.epsilon)
    W = np.array(W_init, dtype=np.complex128, copy=True)
    gamma_local = np.full(cfg.n_ap, 1.0, dtype=float)
    dual = np.zeros(cfg.n_ap, dtype=float)
    z = 1.0
    psi = np.stack(
        [_local_interference_bound(hs, zero_eps, W, tx) for hs in h_samples], axis=0
    )
    rows: List[Dict[str, float]] = []
    status = "max_iters"

    for iteration in range(1, admm.max_iters + 1):
        z_previous = z
        W_previous_outer = W.copy()
        local_statuses: List[str] = []
        total_slack = 0.0

        for a in tx:
            W_prev = W[:, :, a].copy()
            Wa = cp.Variable((cfg.n_ant, cfg.n_streams), complex=True)
            gamma_a = cp.Variable(nonneg=True)
            slack = cp.Variable((n_channel_scenarios, cfg.n_users), nonneg=True)

            constraints = [
                cp.sum_squares(cp.abs(Wa)) <= cfg.p_max_w,
                gamma_a <= admm.gamma_cap_linear,
            ]

            for k in range(n_channel_scenarios):
                for u in range(cfg.n_users):
                    h = h_samples[k, u, :, a]
                    w0 = W_prev[:, u]
                    s0 = np.vdot(h, w0)
                    s_expr = h.conj() @ Wa[:, u]
                    g_bar = 2.0 * cp.real(np.conj(s0) * s_expr) - float(abs(s0) ** 2)
                    rhs_scale = float(
                        eta[u, a]
                        * (
                            psi[k, u]
                            + np.sqrt(scenario.normalized_noise_variance)
                        )
                        ** 2
                    )
                    constraints.append(g_bar >= rhs_scale * gamma_a - slack[k, u])

            sensing_surrogate = 0.0
            for t in range(cfg.n_targets):
                av = scenario.target_steering[t, :, a]
                v0 = av.conj() @ W_prev
                v = av.conj() @ Wa
                f_bar = 2.0 * cp.real(cp.sum(cp.multiply(np.conj(v0), v))) - float(
                    np.linalg.norm(v0) ** 2
                )
                sensing_surrogate += float(scenario.zeta2[t, a]) * f_bar
            sensing_surrogate /= max(cfg.n_targets, 1)

            prox = cp.sum_squares(cp.abs(Wa - W_prev))
            objective = cp.Maximize(
                admm.lambda_comm * gamma_a
                + (1.0 - admm.lambda_comm) * sensing_surrogate
                - 0.5 * admm.rho * cp.square(gamma_a - z + dual[a])
                - admm.slack_penalty * cp.sum(slack) / n_channel_scenarios
                - 0.5 * admm.proximal_weight * prox
            )
            problem = cp.Problem(objective, constraints)
            try:
                problem.solve(**_solver_kwargs(admm))
            except Exception as first_error:
                try:
                    problem.solve(
                        solver=cp.SCS,
                        max_iters=max(10_000, admm.solver_max_iters),
                        eps=1e-5,
                        verbose=admm.verbose_solver,
                    )
                except Exception as second_error:  # pragma: no cover
                    local_statuses.append(f"error:{type(second_error).__name__}")
                    warnings.warn(
                        f"AP {a} local scenario solve failed: {first_error}; fallback: {second_error}"
                    )
                    continue

            local_statuses.append(str(problem.status))
            if Wa.value is None or gamma_a.value is None:
                continue
            candidate = np.asarray(Wa.value, dtype=np.complex128)
            if not np.all(np.isfinite(candidate)):
                continue
            W[:, :, a] = _project_to_ap_power(candidate, cfg.p_max_w)
            gamma_local[a] = float(max(gamma_a.value, 0.0))
            if slack.value is not None:
                total_slack += float(np.sum(np.maximum(slack.value, 0.0)))

        z = float(max(0.0, np.mean(gamma_local[tx] + dual[tx])))
        primal = float(np.linalg.norm(gamma_local[tx] - z))
        dual_residual = float(admm.rho * np.sqrt(n_tx) * abs(z - z_previous))
        dual[tx] += gamma_local[tx] - z

        psi = np.stack(
            [_local_interference_bound(hs, zero_eps, W, tx) for hs in h_samples], axis=0
        )
        beam_change = float(
            np.linalg.norm(W[:, :, tx] - W_previous_outer[:, :, tx])
            / max(np.linalg.norm(W_previous_outer[:, :, tx]), 1e-12)
        )
        row: Dict[str, float] = {
            "iteration": float(iteration),
            "gamma_consensus_linear": z,
            "gamma_consensus_db": 10.0 * np.log10(max(z, 1e-15)),
            "primal_residual": primal,
            "dual_residual": dual_residual,
            "beam_relative_change": beam_change,
            "total_slack": total_slack,
            "psi_mean": float(np.mean(psi)),
            "n_channel_scenarios": float(n_channel_scenarios),
        }
        if evaluate_each_iteration:
            true_sinr = sinr_db(
                scenario.h_true, W, tx, scenario.normalized_noise_variance
            )
            row.update(
                {
                    "true_min_sinr_db": float(np.min(true_sinr)),
                    "true_mean_sinr_db": float(np.mean(true_sinr)),
                    "worst_target_snr_db": float(
                        np.min(sensing_snr_db(cfg, scenario, W))
                    ),
                }
            )
        rows.append(row)

        eps_primal = np.sqrt(n_tx) * admm.abs_tol + admm.rel_tol * max(
            np.linalg.norm(gamma_local[tx]), np.sqrt(n_tx) * abs(z)
        )
        eps_dual = np.sqrt(n_tx) * admm.abs_tol + admm.rel_tol * np.linalg.norm(
            admm.rho * dual[tx]
        )
        if (
            iteration >= admm.min_iters
            and primal <= eps_primal
            and dual_residual <= eps_dual
            and beam_change <= 5.0 * admm.rel_tol
        ):
            status = "converged"
            break

    history = pd.DataFrame(rows)
    runtime = time.perf_counter() - start
    if any(s.startswith("error") for s in local_statuses):
        status += "_with_local_errors"
    return OptimizationResult(
        W=W,
        gamma_consensus=z,
        gamma_local=gamma_local,
        history=history,
        status=status,
        runtime_s=float(runtime),
        eta=eta,
        epsilon=csi.epsilon,
    )


# ---------------------------------------------------------------------------
# Optional centralized robust SOCP benchmark for a fixed SINR target
# ---------------------------------------------------------------------------

def centralized_robust_isac_socp(
    cfg: SystemConfig,
    scenario: Scenario,
    csi: CSIRealization,
    gamma_target_db: float,
    use_uncertainty_margin: bool = True,
    solver: str = "CLARABEL",
) -> Tuple[Optional[Array], str, float]:
    """Centralized robust benchmark for a fixed communication SINR target.

    It maximizes coherent dedicated-sensing-stream amplitude under conservative
    robust SINR constraints. The result is a benchmark, not the same objective as
    the distributed SCA formulation, so comparisons should be described carefully.
    """
    start = time.perf_counter()
    tx = np.asarray(scenario.tx_aps, dtype=int)
    eps = csi.epsilon if use_uncertainty_margin else np.zeros_like(csi.epsilon)
    gamma = 10.0 ** (gamma_target_db / 10.0)
    W_vars = {
        int(a): cp.Variable((cfg.n_ant, cfg.n_streams), complex=True) for a in tx
    }
    constraints = [
        cp.sum_squares(cp.abs(W_vars[int(a)])) <= cfg.p_max_w for a in tx
    ]

    for u in range(cfg.n_users):
        desired_nominal = 0.0
        desired_uncertainty = 0.0
        for a in tx:
            desired_nominal += csi.h_hat[u, :, a].conj() @ W_vars[int(a)][:, u]
            desired_uncertainty += float(eps[u, a]) * cp.norm(
                W_vars[int(a)][:, u], 2
            )
        constraints.append(cp.imag(desired_nominal) == 0.0)
        desired_lower = cp.real(desired_nominal) - desired_uncertainty

        interference_uppers = []
        for i in range(cfg.n_streams):
            if i == u:
                continue
            nominal_i = 0.0
            uncertainty_i = 0.0
            for a in tx:
                nominal_i += csi.h_hat[u, :, a].conj() @ W_vars[int(a)][:, i]
                uncertainty_i += float(eps[u, a]) * cp.norm(
                    W_vars[int(a)][:, i], 2
                )
            interference_uppers.append(cp.abs(nominal_i) + uncertainty_i)
        soc_vector = cp.hstack(
            interference_uppers + [np.sqrt(scenario.normalized_noise_variance)]
        )
        constraints.append(cp.norm(soc_vector, 2) <= desired_lower / np.sqrt(gamma))

    # Coherent dedicated sensing stream for target 0.
    sensing_amp = 0.0
    sensing_col = cfg.n_users
    for a in tx:
        sensing_amp += (
            np.sqrt(max(scenario.zeta2[0, a], 0.0))
            * scenario.target_steering[0, :, a].conj()
            @ W_vars[int(a)][:, sensing_col]
        )
    constraints.append(cp.imag(sensing_amp) == 0.0)
    problem = cp.Problem(cp.Maximize(cp.real(sensing_amp)), constraints)

    try:
        if solver.upper() == "CLARABEL":
            problem.solve(solver=cp.CLARABEL, max_iter=10_000)
        else:
            problem.solve(solver=cp.SCS, max_iters=20_000, eps=1e-5)
    except Exception:
        problem.solve(solver=cp.SCS, max_iters=20_000, eps=1e-5)

    runtime = time.perf_counter() - start
    if problem.status not in {cp.OPTIMAL, cp.OPTIMAL_INACCURATE}:
        return None, str(problem.status), float(runtime)
    W = np.zeros((cfg.n_ant, cfg.n_streams, cfg.n_ap), dtype=np.complex128)
    for a in tx:
        if W_vars[int(a)].value is None:
            return None, "missing_solution", float(runtime)
        W[:, :, a] = _project_to_ap_power(
            np.asarray(W_vars[int(a)].value, dtype=np.complex128), cfg.p_max_w
        )
    return W, str(problem.status), float(runtime)


# ---------------------------------------------------------------------------
# Reproducible experiment runners and confidence intervals
# ---------------------------------------------------------------------------

def run_methods_on_same_realization(
    cfg: SystemConfig,
    pilot_snr_db: float,
    seed: int,
    admm: ADMMConfig,
    methods: Sequence[str] = (
        "nominal_uniform",
        "nominal_gain_eta",
        "robust_uniform",
        "proposed_robust_uncertainty_eta",
        "proposed_scenario_robust_eta",
    ),
    confidence: float = 0.95,
    sinr_target_db: float = 5.0,
    n_channel_scenarios: int = 6,
) -> Tuple[pd.DataFrame, Dict[str, OptimizationResult]]:
    """Fair comparison: every method sees the same topology, true channel, and CSI error."""
    scenario = generate_true_scenario(cfg, seed=seed)
    base_rng = _rng(seed + 17_000)
    base_error = (
        base_rng.standard_normal(scenario.h_true.shape)
        + 1j * base_rng.standard_normal(scenario.h_true.shape)
    ) / np.sqrt(2.0)
    csi = estimate_csi(
        scenario.h_true,
        pilot_snr_db=pilot_snr_db,
        rx_ap=scenario.rx_ap,
        seed=seed + 23_000,
        confidence=confidence,
        base_error=base_error,
    )
    W0 = initialize_rzf_nsc(cfg, scenario, csi.h_hat)
    rows: List[Dict[str, object]] = []
    results: Dict[str, OptimizationResult] = {}

    for method in methods:
        if method == "nominal_uniform":
            eta = compute_eta(csi.h_hat, np.zeros_like(csi.epsilon), scenario.tx_aps, "uniform")
            robust = False
        elif method == "nominal_gain_eta":
            eta = compute_eta(csi.h_hat, np.zeros_like(csi.epsilon), scenario.tx_aps, "gain")
            robust = False
        elif method == "robust_uniform":
            eta = compute_eta(csi.h_hat, csi.epsilon, scenario.tx_aps, "uniform")
            robust = True
        elif method == "proposed_robust_uncertainty_eta":
            eta = compute_eta(
                csi.h_hat, csi.epsilon, scenario.tx_aps, "uncertainty_aware"
            )
            robust = True
        elif method == "proposed_scenario_robust_eta":
            eta = compute_eta(
                csi.h_hat, csi.epsilon, scenario.tx_aps, "uncertainty_aware"
            )
            robust = True
        else:
            raise ValueError(f"Unknown method: {method}")

        if method == "proposed_scenario_robust_eta":
            result = scenario_sca_consensus_admm(
                cfg,
                scenario,
                csi,
                eta,
                W0,
                admm=admm,
                n_channel_scenarios=n_channel_scenarios,
                scenario_seed=seed + 31_000,
                evaluate_each_iteration=False,
            )
        else:
            result = robust_sca_consensus_admm(
                cfg,
                scenario,
                csi,
                eta,
                W0,
                admm=admm,
                use_uncertainty_margin=robust,
                evaluate_each_iteration=False,
            )
        metrics = summarize_metrics(cfg, scenario, result.W, sinr_target_db)
        metrics.update(
            {
                "seed": int(seed),
                "pilot_snr_db": float(pilot_snr_db),
                "method": method,
                "runtime_s": result.runtime_s,
                "iterations": int(len(result.history)),
                "status": result.status,
                "gamma_consensus_db": 10.0
                * np.log10(max(result.gamma_consensus, 1e-15)),
                "csi_nmse_db": float(
                    10.0
                    * np.log10(
                        np.linalg.norm(csi.error) ** 2
                        / max(np.linalg.norm(scenario.h_true) ** 2, 1e-30)
                    )
                ),
            }
        )
        rows.append(metrics)
        results[method] = result

    return pd.DataFrame(rows), results


def run_monte_carlo(
    cfg: SystemConfig,
    pilot_snrs_db: Sequence[float],
    seeds: Sequence[int],
    admm: ADMMConfig,
    methods: Sequence[str] = (
        "nominal_uniform",
        "nominal_gain_eta",
        "robust_uniform",
        "proposed_robust_uncertainty_eta",
        "proposed_scenario_robust_eta",
    ),
    confidence: float = 0.95,
    sinr_target_db: float = 5.0,
    n_channel_scenarios: int = 6,
    checkpoint_csv: Optional[str | Path] = None,
) -> pd.DataFrame:
    frames: List[pd.DataFrame] = []
    checkpoint = Path(checkpoint_csv) if checkpoint_csv else None
    for pilot in pilot_snrs_db:
        for seed in seeds:
            frame, _ = run_methods_on_same_realization(
                cfg,
                pilot_snr_db=float(pilot),
                seed=int(seed),
                admm=admm,
                methods=methods,
                confidence=confidence,
                sinr_target_db=sinr_target_db,
                n_channel_scenarios=n_channel_scenarios,
            )
            frames.append(frame)
            if checkpoint is not None:
                checkpoint.parent.mkdir(parents=True, exist_ok=True)
                pd.concat(frames, ignore_index=True).to_csv(checkpoint, index=False)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def mean_ci95(values: Iterable[float]) -> Tuple[float, float]:
    x = np.asarray(list(values), dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return float("nan"), float("nan")
    mean = float(np.mean(x))
    if x.size == 1:
        return mean, 0.0
    half = float(1.96 * np.std(x, ddof=1) / np.sqrt(x.size))
    return mean, half


def aggregate_results(
    results: pd.DataFrame,
    metrics: Sequence[str] = (
        "min_sinr_db",
        "sinr_outage",
        "worst_target_snr_db",
        "worst_target_crb_deg2",
        "runtime_s",
        "iterations",
    ),
) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    for (pilot, method), group in results.groupby(["pilot_snr_db", "method"], dropna=False):
        row: Dict[str, object] = {
            "pilot_snr_db": pilot,
            "method": method,
            "n": int(len(group)),
        }
        for metric in metrics:
            mean, half = mean_ci95(group[metric].astype(float))
            row[f"{metric}_mean"] = mean
            row[f"{metric}_ci95"] = half
        rows.append(row)
    return pd.DataFrame(rows).sort_values(["pilot_snr_db", "method"]).reset_index(drop=True)


def save_experiment_bundle(
    output_dir: str | Path,
    cfg: SystemConfig,
    admm: ADMMConfig,
    raw_results: pd.DataFrame,
    summary: Optional[pd.DataFrame] = None,
) -> Path:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    raw_results.to_csv(out / "raw_results.csv", index=False)
    if summary is None:
        summary = aggregate_results(raw_results)
    summary.to_csv(out / "summary_95ci.csv", index=False)
    with open(out / "configuration.json", "w", encoding="utf-8") as f:
        json.dump(
            {"system": asdict(cfg), "admm": asdict(admm)}, f, indent=2, sort_keys=True
        )
    return out


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

def validate_result(
    cfg: SystemConfig,
    scenario: Scenario,
    csi: CSIRealization,
    result: OptimizationResult,
    atol_power: float = 5e-4,
) -> Dict[str, bool]:
    tx = scenario.tx_aps
    checks = {
        "true_and_estimated_channels_are_distinct": bool(
            np.linalg.norm(csi.h_hat - scenario.h_true) > 0.0
        ),
        "eta_sums_to_one_per_user": bool(
            np.allclose(result.eta[:, tx].sum(axis=1), 1.0, atol=1e-8)
        ),
        "per_ap_power_feasible": bool(
            np.max(per_ap_power(result.W)[tx]) <= cfg.p_max_w + atol_power
        ),
        "finite_beamformers": bool(np.all(np.isfinite(result.W))),
        "finite_history": bool(
            result.history.select_dtypes(include=[np.number]).replace([np.inf, -np.inf], np.nan).notna().all().all()
        ),
        "gamma_is_dimensionless_and_nonnegative": bool(result.gamma_consensus >= 0.0),
    }
    return checks


__all__ = [
    "SystemConfig",
    "ADMMConfig",
    "Scenario",
    "CSIRealization",
    "OptimizationResult",
    "generate_true_scenario",
    "estimate_csi",
    "sample_csi_scenarios",
    "initialize_rzf_nsc",
    "compute_eta",
    "robust_sca_consensus_admm",
    "scenario_sca_consensus_admm",
    "centralized_robust_isac_socp",
    "sinr_db",
    "sensing_snr_db",
    "azimuth_crb_deg2",
    "summarize_metrics",
    "run_methods_on_same_realization",
    "run_monte_carlo",
    "aggregate_results",
    "save_experiment_bundle",
    "validate_result",
    "mean_ci95",
]
# ---------------------------------------------------------------------------
# V7 stabilized scenario-robust global-SINR block-SCA
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class V7Config:
    """Configuration for the stabilized V7 coordinated block-SCA method.

    V7 replaces the overly conservative local fair-share SINR surrogate used by
    the V6 proposed method with a direct *global received-signal* SCA constraint.
    Each AP is updated while the other AP beamformers are fixed. Only aggregated
    received-stream summaries are needed from the coordinator; full global CSI
    does not need to be sent to every AP.
    """

    sinr_target_db: float = 0.0
    n_train_scenarios: int = 8
    n_validation_scenarios: int = 64
    max_sweeps: int = 15
    min_sweeps: int = 4
    beam_change_tol: float = 2e-3
    convergence_patience: int = 3

    damping: float = 0.50
    trust_region_initial: float = 0.70
    trust_region_min: float = 0.10
    trust_region_decay: float = 0.85

    slack_penalty: float = 10_000.0
    slack_tolerance: float = 1e-5
    proximal_weight: float = 1.0
    eta_prox_strength: float = 0.25

    sensing_objective_weight: float = 0.10
    sensing_snr_weight: float = 0.25
    sensing_fim_weight: float = 0.75
    sensing_snr_floor_ratio: float = 0.95
    sensing_fim_floor_ratio: float = 0.95

    solver: str = "CLARABEL"
    solver_max_iters: int = 10_000
    verbose_solver: bool = False


def bonferroni_link_confidence(
    n_users: int,
    n_tx_aps: int,
    joint_confidence: float = 0.95,
) -> float:
    """Per-link confidence giving a conservative network-wide confidence.

    A 95% ball for every link separately is not a 95% joint set. This helper
    applies the Bonferroni allocation 1-(1-joint)/(U*A_tx).
    """
    if not 0.0 < joint_confidence < 1.0:
        raise ValueError("joint_confidence must be in (0,1)")
    n_links = max(int(n_users) * int(n_tx_aps), 1)
    return float(1.0 - (1.0 - joint_confidence) / n_links)


def evaluate_channel_samples(
    cfg: SystemConfig,
    scenario: Scenario,
    W: Array,
    channel_samples: Array,
    sinr_target_db: float,
) -> Dict[str, float]:
    """Evaluate a beamformer on held-out CSI-error samples.

    The validation samples are never used in the local optimization problems.
    This prevents best-iterate selection from peeking at the physical true
    channel while still protecting against overfitting to the training scenarios.
    """
    min_sinrs: List[float] = []
    user_outages: List[float] = []
    for h_eval in channel_samples:
        values = sinr_db(
            h_eval,
            W,
            scenario.tx_aps,
            scenario.normalized_noise_variance,
        )
        min_sinrs.append(float(np.min(values)))
        user_outages.append(float(np.mean(values < sinr_target_db)))
    x = np.asarray(min_sinrs, dtype=float)
    o = np.asarray(user_outages, dtype=float)
    return {
        "validation_user_outage": float(np.mean(o)),
        "validation_network_outage": float(np.mean(x < sinr_target_db)),
        "validation_min_sinr_mean_db": float(np.mean(x)),
        "validation_min_sinr_p05_db": float(np.quantile(x, 0.05)),
        "validation_min_sinr_worst_db": float(np.min(x)),
    }


def _v7_solver_kwargs(config: V7Config) -> Dict[str, object]:
    if config.solver.upper() == "CLARABEL":
        return {
            "solver": cp.CLARABEL,
            "max_iter": config.solver_max_iters,
            "verbose": config.verbose_solver,
        }
    if config.solver.upper() == "SCS":
        return {
            "solver": cp.SCS,
            "max_iters": config.solver_max_iters,
            "eps": 1e-5,
            "verbose": config.verbose_solver,
        }
    return {"solver": config.solver, "verbose": config.verbose_solver}


def _v7_sensing_reference(
    cfg: SystemConfig,
    scenario: Scenario,
    W_ref: Array,
) -> Tuple[Array, Array]:
    steering = np.zeros(cfg.n_targets, dtype=float)
    derivative = np.zeros(cfg.n_targets, dtype=float)
    for t in range(cfg.n_targets):
        for a in scenario.tx_aps:
            av = scenario.target_steering[t, :, a]
            dv = scenario.target_derivative[t, :, a]
            steering[t] += scenario.zeta2[t, a] * np.linalg.norm(
                av.conj() @ W_ref[:, :, a]
            ) ** 2
            derivative[t] += scenario.zeta2[t, a] * np.linalg.norm(
                dv.conj() @ W_ref[:, :, a]
            ) ** 2
    return steering, derivative


def _v7_received_from_other_aps(
    h_sample: Array,
    W: Array,
    tx_aps: Sequence[int],
    excluded_ap: int,
) -> Array:
    out = np.zeros((h_sample.shape[0], W.shape[1]), dtype=np.complex128)
    for b in tx_aps:
        if int(b) != int(excluded_ap):
            out += h_sample[:, :, b] @ W[:, :, b]
    return out


def _solve_v7_ap_update(
    cfg: SystemConfig,
    scenario: Scenario,
    h_train: Array,
    eta: Array,
    W_current: Array,
    ap: int,
    gamma_target: float,
    steering_floor: Array,
    derivative_floor: Array,
    trust_radius: float,
    v7: V7Config,
) -> Tuple[Array, float, str]:
    """One convex block-SCA update for a single AP.

    The SINR surrogate uses the global desired and interference contributions:

        2 Re{d0* d} - |d0|^2 >= gamma (I(W_a)+noise) - slack.

    This is tight at the current iterate and is much less conservative than
    forcing every AP to meet an isolated fair-share SINR contribution.
    """
    n_scenarios = h_train.shape[0]
    W_prev = W_current[:, :, ap].copy()
    Wa = cp.Variable((cfg.n_ant, cfg.n_streams), complex=True)
    slack = cp.Variable((n_scenarios, cfg.n_users), nonneg=True)

    constraints = [
        cp.sum_squares(cp.abs(Wa)) <= cfg.p_max_w,
        cp.norm(Wa - W_prev, "fro") <= trust_radius,
    ]

    for k in range(n_scenarios):
        h_k = h_train[k]
        other = _v7_received_from_other_aps(
            h_k, W_current, scenario.tx_aps, excluded_ap=ap
        )
        current_total = other + h_k[:, :, ap] @ W_prev
        for u in range(cfg.n_users):
            # h stores the row-channel convention used by received_stream_matrix;
            # therefore no extra conjugation is applied here.
            desired = other[u, u] + h_k[u, :, ap] @ Wa[:, u]
            desired_0 = current_total[u, u]
            desired_lower = (
                2.0 * cp.real(np.conj(desired_0) * desired)
                - float(abs(desired_0) ** 2)
            )
            interference_terms = [
                other[u, i] + h_k[u, :, ap] @ Wa[:, i]
                for i in range(cfg.n_streams)
                if i != u
            ]
            interference_power = (
                cp.sum_squares(cp.abs(cp.hstack(interference_terms)))
                + scenario.normalized_noise_variance
            )
            constraints.append(
                desired_lower
                >= gamma_target * interference_power - slack[k, u]
            )

    # Preserve both detection SNR and angle-information (inverse CRB) relative
    # to the common initializer. The current point is feasible because the
    # floors are <= the initializer reference and each SCA surrogate is tight.
    sensing_objective = 0.0
    for t in range(cfg.n_targets):
        for vector_kind, vector, objective_weight, floor_value in (
            (
                "steering",
                scenario.target_steering[t, :, ap],
                v7.sensing_snr_weight,
                steering_floor[t],
            ),
            (
                "derivative",
                scenario.target_derivative[t, :, ap],
                v7.sensing_fim_weight,
                derivative_floor[t],
            ),
        ):
            v0 = vector.conj() @ W_prev
            v_expr = vector.conj() @ Wa
            local_lower = (
                2.0
                * cp.real(cp.sum(cp.multiply(np.conj(v0), v_expr)))
                - float(np.linalg.norm(v0) ** 2)
            )
            if vector_kind == "steering":
                other_power = sum(
                    scenario.zeta2[t, b]
                    * np.linalg.norm(
                        scenario.target_steering[t, :, b].conj()
                        @ W_current[:, :, b]
                    )
                    ** 2
                    for b in scenario.tx_aps
                    if int(b) != int(ap)
                )
            else:
                other_power = sum(
                    scenario.zeta2[t, b]
                    * np.linalg.norm(
                        scenario.target_derivative[t, :, b].conj()
                        @ W_current[:, :, b]
                    )
                    ** 2
                    for b in scenario.tx_aps
                    if int(b) != int(ap)
                )
            constraints.append(
                float(other_power)
                + float(scenario.zeta2[t, ap]) * local_lower
                >= float(floor_value)
            )
            local_ref = max(
                float(scenario.zeta2[t, ap]) * np.linalg.norm(v0) ** 2,
                1e-3,
            )
            sensing_objective += (
                objective_weight
                * float(scenario.zeta2[t, ap])
                * local_lower
                / local_ref
            )

    # Eta is retained as user-specific update regularization: reliable AP-user
    # links are allowed to move more, while weak/uncertain links are stabilized.
    eta_ap = eta[:, ap]
    eta_scale = eta_ap / max(float(np.max(eta_ap)), 1e-12)
    prox_comm = 0.0
    for u in range(cfg.n_users):
        weight = 1.0 + v7.eta_prox_strength * (1.0 - float(eta_scale[u]))
        prox_comm += weight * cp.sum_squares(cp.abs(Wa[:, u] - W_prev[:, u]))
    prox_sens = cp.sum_squares(
        cp.abs(Wa[:, cfg.n_users :] - W_prev[:, cfg.n_users :])
    )
    prox = prox_comm + prox_sens

    objective = cp.Minimize(
        v7.slack_penalty * cp.sum(slack) / (n_scenarios * cfg.n_users)
        + v7.proximal_weight * prox
        - v7.sensing_objective_weight * sensing_objective
    )
    problem = cp.Problem(objective, constraints)
    try:
        problem.solve(**_v7_solver_kwargs(v7))
    except Exception as first_error:
        try:
            problem.solve(
                solver=cp.SCS,
                max_iters=max(20_000, v7.solver_max_iters),
                eps=1e-5,
                verbose=v7.verbose_solver,
            )
        except Exception as second_error:  # pragma: no cover
            warnings.warn(
                f"V7 AP {ap} solve failed: {first_error}; fallback: {second_error}"
            )
            return W_prev, float("inf"), f"error:{type(second_error).__name__}"

    if Wa.value is None or not np.all(np.isfinite(Wa.value)):
        return W_prev, float("inf"), str(problem.status)
    candidate = np.asarray(Wa.value, dtype=np.complex128)
    candidate = _project_to_ap_power(candidate, cfg.p_max_w)
    total_slack = (
        float(np.sum(np.maximum(np.asarray(slack.value, dtype=float), 0.0)))
        if slack.value is not None
        else float("inf")
    )
    return candidate, total_slack, str(problem.status)


def stabilized_scenario_block_sca(
    cfg: SystemConfig,
    scenario: Scenario,
    csi: CSIRealization,
    eta: Array,
    W_init: Array,
    v7: V7Config = V7Config(),
    scenario_seed: int = 9876,
    validation_seed: Optional[int] = None,
    evaluate_true_each_sweep: bool = True,
) -> OptimizationResult:
    """V7 feasibility-first scenario-robust coordinated block-SCA.

    Main corrections relative to V6:
    1. fixed QoS target removes communication/sensing objective-scale mismatch;
    2. direct global-SINR SCA constraints replace the loose local fair-share bound;
    3. channel row/conjugation convention matches the final SINR evaluator;
    4. trust regions and damping stabilize successive updates;
    5. sensing-SNR and FIM floors prevent sensing/CRB collapse;
    6. an independent held-out CSI sample selects the returned iterate;
    7. the initializer is a candidate, so the returned validation score cannot be
       worse than the common starting point under the lexicographic criterion.
    """
    start = time.perf_counter()
    if eta.shape != (cfg.n_users, cfg.n_ap):
        raise ValueError("eta must have shape (n_users, n_ap)")
    if not 0.0 < v7.damping <= 1.0:
        raise ValueError("damping must be in (0,1]")
    if v7.n_train_scenarios < 1 or v7.n_validation_scenarios < 1:
        raise ValueError("scenario counts must be positive")

    validation_seed = (
        int(scenario_seed) + 1_000_003
        if validation_seed is None
        else int(validation_seed)
    )
    h_train = sample_csi_scenarios(
        csi,
        n_scenarios=v7.n_train_scenarios,
        seed=int(scenario_seed),
        include_nominal=True,
    )
    h_validation = sample_csi_scenarios(
        csi,
        n_scenarios=v7.n_validation_scenarios,
        seed=validation_seed,
        include_nominal=False,
    )

    W = np.array(W_init, dtype=np.complex128, copy=True)
    gamma_target = 10.0 ** (v7.sinr_target_db / 10.0)
    steering_ref, derivative_ref = _v7_sensing_reference(cfg, scenario, W_init)
    steering_floor = v7.sensing_snr_floor_ratio * steering_ref
    derivative_floor = v7.sensing_fim_floor_ratio * derivative_ref

    initial_validation = evaluate_channel_samples(
        cfg, scenario, W, h_validation, v7.sinr_target_db
    )
    initial_true = summarize_metrics(cfg, scenario, W, v7.sinr_target_db)
    best_W = W.copy()
    best_sweep = 0
    best_score = (
        initial_validation["validation_network_outage"],
        initial_validation["validation_user_outage"],
        -initial_validation["validation_min_sinr_p05_db"],
        -initial_true["worst_target_snr_db"],
        initial_true["worst_target_crb_deg2"],
    )

    rows: List[Dict[str, float]] = []
    stable_count = 0
    any_solver_error = False
    status = "max_sweeps_best_holdout_iterate"

    for sweep in range(1, v7.max_sweeps + 1):
        W_before = W.copy()
        total_slack = 0.0
        sweep_statuses: List[str] = []
        trust_radius = max(
            v7.trust_region_min,
            v7.trust_region_initial * v7.trust_region_decay ** (sweep - 1),
        )

        # High-confidence APs update first; the ordering is deterministic.
        ap_priority = sorted(
            [int(a) for a in scenario.tx_aps],
            key=lambda a: -float(np.mean(eta[:, a])),
        )
        for a in ap_priority:
            candidate, local_slack, local_status = _solve_v7_ap_update(
                cfg,
                scenario,
                h_train,
                eta,
                W,
                ap=a,
                gamma_target=gamma_target,
                steering_floor=steering_floor,
                derivative_floor=derivative_floor,
                trust_radius=trust_radius,
                v7=v7,
            )
            sweep_statuses.append(local_status)
            if local_status.startswith("error"):
                any_solver_error = True
            if np.isfinite(local_slack):
                total_slack += local_slack
            else:
                any_solver_error = True
            damped = (1.0 - v7.damping) * W[:, :, a] + v7.damping * candidate
            W[:, :, a] = _project_to_ap_power(damped, cfg.p_max_w)

        beam_change = float(
            np.linalg.norm(W[:, :, scenario.tx_aps] - W_before[:, :, scenario.tx_aps])
            / max(np.linalg.norm(W_before[:, :, scenario.tx_aps]), 1e-12)
        )
        validation = evaluate_channel_samples(
            cfg, scenario, W, h_validation, v7.sinr_target_db
        )
        true_metrics = summarize_metrics(cfg, scenario, W, v7.sinr_target_db)
        score = (
            validation["validation_network_outage"],
            validation["validation_user_outage"],
            -validation["validation_min_sinr_p05_db"],
            -true_metrics["worst_target_snr_db"],
            true_metrics["worst_target_crb_deg2"],
        )
        improved = score < best_score
        if improved:
            best_score = score
            best_W = W.copy()
            best_sweep = sweep

        row: Dict[str, float] = {
            "sweep": float(sweep),
            "beam_relative_change": beam_change,
            "total_slack": float(total_slack),
            "trust_radius": float(trust_radius),
            "best_sweep_so_far": float(best_sweep),
            "is_best_sweep": float(improved),
            **validation,
        }
        if evaluate_true_each_sweep:
            row.update(
                {
                    "true_min_sinr_db": true_metrics["min_sinr_db"],
                    "true_mean_sinr_db": true_metrics["mean_sinr_db"],
                    "true_sinr_outage": true_metrics["sinr_outage"],
                    "worst_target_snr_db": true_metrics["worst_target_snr_db"],
                    "worst_target_crb_deg2": true_metrics[
                        "worst_target_crb_deg2"
                    ],
                }
            )
        rows.append(row)

        if beam_change <= v7.beam_change_tol and total_slack <= v7.slack_tolerance:
            stable_count += 1
        else:
            stable_count = 0
        if sweep >= v7.min_sweeps and stable_count >= v7.convergence_patience:
            status = "converged_best_holdout_iterate"
            break

    history = pd.DataFrame(rows)
    if any_solver_error:
        status += "_with_solver_warnings"
    status += f";best_sweep={best_sweep}"
    runtime = time.perf_counter() - start
    gamma_local = np.zeros(cfg.n_ap, dtype=float)
    gamma_local[scenario.tx_aps] = gamma_target
    return OptimizationResult(
        W=best_W,
        gamma_consensus=gamma_target,
        gamma_local=gamma_local,
        history=history,
        status=status,
        runtime_s=float(runtime),
        eta=eta,
        epsilon=csi.epsilon,
    )


def add_unseen_error_metrics(
    row: Dict[str, object],
    cfg: SystemConfig,
    scenario: Scenario,
    csi: CSIRealization,
    W: Array,
    sinr_target_db: float,
    n_test_errors: int,
    test_seed: int,
) -> Dict[str, object]:
    samples = sample_csi_scenarios(
        csi,
        n_scenarios=n_test_errors,
        seed=test_seed,
        include_nominal=False,
    )
    validation = evaluate_channel_samples(
        cfg, scenario, W, samples, sinr_target_db
    )
    row.update(
        {
            "unseen_user_outage": validation["validation_user_outage"],
            "unseen_network_outage": validation["validation_network_outage"],
            "unseen_min_sinr_mean_db": validation[
                "validation_min_sinr_mean_db"
            ],
            "unseen_min_sinr_p05_db": validation[
                "validation_min_sinr_p05_db"
            ],
            "unseen_min_sinr_worst_db": validation[
                "validation_min_sinr_worst_db"
            ],
        }
    )
    return row


def run_v7_methods_on_same_realization(
    cfg: SystemConfig,
    pilot_snr_db: float,
    seed: int,
    admm: ADMMConfig,
    v7: V7Config,
    methods: Sequence[str] = (
        "initializer",
        "v6_nominal_gain_eta",
        "v6_scenario_robust_eta",
        "worstcase_robust_socp",
        "v7_nominal_global_sca_gain_eta",
        "v7_scenario_global_sca_uniform",
        "v7_scenario_global_sca_gain_eta",
        "v7_scenario_global_sca_uncertainty_eta",
    ),
    joint_confidence: float = 0.95,
    n_unseen_test_errors: int = 64,
    pilot_length: int = 1,
    estimator: str = "ls",
) -> Tuple[pd.DataFrame, Dict[str, OptimizationResult]]:
    """Fair V7 ablation on exactly the same topology, CSI error, and test errors."""
    scenario = generate_true_scenario(cfg, seed=seed)
    base_rng = _rng(seed + 17_000)
    base_error = (
        base_rng.standard_normal(scenario.h_true.shape)
        + 1j * base_rng.standard_normal(scenario.h_true.shape)
    ) / np.sqrt(2.0)
    per_link_confidence = bonferroni_link_confidence(
        cfg.n_users, len(scenario.tx_aps), joint_confidence
    )
    csi = estimate_csi(
        scenario.h_true,
        pilot_snr_db=pilot_snr_db,
        rx_ap=scenario.rx_ap,
        seed=seed + 23_000,
        confidence=per_link_confidence,
        base_error=base_error,
        pilot_length=pilot_length,
        estimator=estimator,
    )
    W0 = initialize_rzf_nsc(cfg, scenario, csi.h_hat)
    eta_uniform = compute_eta(
        csi.h_hat, np.zeros_like(csi.epsilon), scenario.tx_aps, "uniform"
    )
    eta_gain = compute_eta(
        csi.h_hat, np.zeros_like(csi.epsilon), scenario.tx_aps, "gain"
    )
    eta_uncertain = compute_eta(
        csi.h_hat, csi.epsilon, scenario.tx_aps, "uncertainty_aware"
    )

    rows: List[Dict[str, object]] = []
    results: Dict[str, OptimizationResult] = {}
    test_seed = seed + 91_000

    for method in methods:
        if method == "initializer":
            result = OptimizationResult(
                W=W0.copy(),
                gamma_consensus=10.0 ** (v7.sinr_target_db / 10.0),
                gamma_local=np.zeros(cfg.n_ap),
                history=pd.DataFrame(),
                status="initializer",
                runtime_s=0.0,
                eta=eta_gain,
                epsilon=csi.epsilon,
            )
        elif method == "v6_nominal_gain_eta":
            result = robust_sca_consensus_admm(
                cfg,
                scenario,
                csi,
                eta_gain,
                W0,
                admm=admm,
                use_uncertainty_margin=False,
                evaluate_each_iteration=False,
            )
        elif method == "v6_scenario_robust_eta":
            result = scenario_sca_consensus_admm(
                cfg,
                scenario,
                csi,
                eta_uncertain,
                W0,
                admm=admm,
                n_channel_scenarios=v7.n_train_scenarios,
                scenario_seed=seed + 31_000,
                evaluate_each_iteration=False,
            )
        elif method == "worstcase_robust_socp":
            W_wc, status_wc, rt_wc = centralized_robust_isac_socp(
                cfg,
                scenario,
                csi,
                gamma_target_db=v7.sinr_target_db,
                use_uncertainty_margin=True,
            )
            if W_wc is None:
                W_wc = W0.copy()
            result = OptimizationResult(
                W=W_wc,
                gamma_consensus=10.0 ** (v7.sinr_target_db / 10.0),
                gamma_local=np.zeros(cfg.n_ap),
                history=pd.DataFrame(),
                status=f"worstcase_socp:{status_wc}",
                runtime_s=float(rt_wc),
                eta=eta_gain,
                epsilon=csi.epsilon,
            )
        elif method.startswith("v7_"):
            if method == "v7_nominal_global_sca_gain_eta":
                eta = eta_gain
                method_cfg = replace(
                    v7,
                    n_train_scenarios=1,
                    n_validation_scenarios=v7.n_validation_scenarios,
                )
            elif method == "v7_scenario_global_sca_uniform":
                eta = eta_uniform
                method_cfg = v7
            elif method == "v7_scenario_global_sca_gain_eta":
                eta = eta_gain
                method_cfg = v7
            elif method == "v7_scenario_global_sca_uncertainty_eta":
                eta = eta_uncertain
                method_cfg = v7
            else:
                raise ValueError(f"Unknown V7 method: {method}")
            result = stabilized_scenario_block_sca(
                cfg,
                scenario,
                csi,
                eta,
                W0,
                v7=method_cfg,
                scenario_seed=seed + 31_000,
                validation_seed=seed + 51_000,
                evaluate_true_each_sweep=False,
            )
        else:
            raise ValueError(f"Unknown method: {method}")

        row: Dict[str, object] = summarize_metrics(
            cfg, scenario, result.W, v7.sinr_target_db
        )
        row.update(
            {
                "seed": int(seed),
                "pilot_snr_db": float(pilot_snr_db),
                "method": method,
                "runtime_s": float(result.runtime_s),
                "iterations": int(len(result.history)),
                "status": result.status,
                "gamma_design_db": float(v7.sinr_target_db),
                "per_link_confidence": float(per_link_confidence),
                "csi_nmse_db": float(
                    10.0
                    * np.log10(
                        np.linalg.norm(csi.error) ** 2
                        / max(np.linalg.norm(scenario.h_true) ** 2, 1e-30)
                    )
                ),
            }
        )
        add_unseen_error_metrics(
            row,
            cfg,
            scenario,
            csi,
            result.W,
            v7.sinr_target_db,
            n_test_errors=n_unseen_test_errors,
            test_seed=test_seed,
        )
        rows.append(row)
        results[method] = result

    return pd.DataFrame(rows), results


def run_v7_monte_carlo(
    cfg: SystemConfig,
    pilot_snrs_db: Sequence[float],
    seeds: Sequence[int],
    admm: ADMMConfig,
    v7: V7Config,
    methods: Sequence[str],
    joint_confidence: float = 0.95,
    n_unseen_test_errors: int = 64,
    pilot_length: int = 1,
    estimator: str = "ls",
    checkpoint_csv: Optional[str | Path] = None,
) -> pd.DataFrame:
    frames: List[pd.DataFrame] = []
    checkpoint = Path(checkpoint_csv) if checkpoint_csv else None
    for pilot in pilot_snrs_db:
        for seed in seeds:
            frame, _ = run_v7_methods_on_same_realization(
                cfg,
                pilot_snr_db=float(pilot),
                seed=int(seed),
                admm=admm,
                v7=v7,
                methods=methods,
                joint_confidence=joint_confidence,
                n_unseen_test_errors=n_unseen_test_errors,
                pilot_length=pilot_length,
                estimator=estimator,
            )
            frames.append(frame)
            if checkpoint is not None:
                checkpoint.parent.mkdir(parents=True, exist_ok=True)
                pd.concat(frames, ignore_index=True).to_csv(checkpoint, index=False)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def paired_method_statistics(
    raw_results: pd.DataFrame,
    proposed_method: str,
    baseline_method: str,
    metric: str,
    lower_is_better: bool = False,
) -> pd.DataFrame:
    """Paired effect, t confidence interval, paired t test, and Wilcoxon test."""
    try:
        from scipy.stats import t as student_t, ttest_rel, wilcoxon
    except ImportError as exc:  # pragma: no cover
        raise ImportError("scipy is required for paired statistics") from exc

    rows: List[Dict[str, object]] = []
    for pilot, group in raw_results.groupby("pilot_snr_db"):
        pivot = group.pivot_table(
            index="seed", columns="method", values=metric, aggfunc="first"
        )
        if proposed_method not in pivot or baseline_method not in pivot:
            continue
        paired = pivot[[proposed_method, baseline_method]].dropna()
        if paired.empty:
            continue
        if lower_is_better:
            diff = paired[baseline_method] - paired[proposed_method]
        else:
            diff = paired[proposed_method] - paired[baseline_method]
        x = diff.to_numpy(dtype=float)
        n = len(x)
        mean_diff = float(np.mean(x))
        sd = float(np.std(x, ddof=1)) if n > 1 else 0.0
        if n > 1 and sd > 0:
            critical = float(student_t.ppf(0.975, df=n - 1))
            ci_half = critical * sd / np.sqrt(n)
            t_p = float(
                ttest_rel(
                    paired[proposed_method], paired[baseline_method]
                ).pvalue
            )
            effect_dz = mean_diff / sd
        else:
            ci_half = 0.0
            t_p = float("nan")
            effect_dz = float("nan")
        try:
            w_p = float(wilcoxon(x).pvalue) if np.any(np.abs(x) > 0) else 1.0
        except ValueError:
            w_p = float("nan")
        rows.append(
            {
                "pilot_snr_db": float(pilot),
                "metric": metric,
                "proposed": proposed_method,
                "baseline": baseline_method,
                "n_pairs": int(n),
                "mean_improvement": mean_diff,
                "ci95_low": mean_diff - ci_half,
                "ci95_high": mean_diff + ci_half,
                "paired_t_pvalue": t_p,
                "wilcoxon_pvalue": w_p,
                "paired_effect_dz": effect_dz,
            }
        )
    return pd.DataFrame(rows)


__all__ += [
    "V7Config",
    "bonferroni_link_confidence",
    "evaluate_channel_samples",
    "stabilized_scenario_block_sca",
    "add_unseen_error_metrics",
    "run_v7_methods_on_same_realization",
    "run_v7_monte_carlo",
    "paired_method_statistics",
]


# ===========================================================================
# RESUBMISSION ADDITIONS (address reviewer code-based comments)
# ===========================================================================

def set_publication_style(dpi: int = 600, base_fontsize: int = 11) -> None:
    """Configure Matplotlib for 600-dpi publication figures (Reviewer 1, C2).

    Call once before generating figures. Every ``savefig`` then exports at the
    configured dpi with tight bounding boxes. Vector PDF is preferred for line
    art; use ``fig.savefig("figX.pdf")`` or ``fig.savefig("figX.png", dpi=600)``.
    """
    import matplotlib as mpl
    mpl.rcParams.update({
        "figure.dpi": 150,
        "savefig.dpi": int(dpi),
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.02,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "font.size": base_fontsize,
        "axes.titlesize": base_fontsize + 1,
        "axes.labelsize": base_fontsize,
        "xtick.labelsize": base_fontsize - 1,
        "ytick.labelsize": base_fontsize - 1,
        "legend.fontsize": base_fontsize - 1,
        "lines.linewidth": 1.6,
        "axes.grid": True,
        "grid.alpha": 0.3,
    })


def detection_probability(
    sensing_snr_db: Array,
    pfa: float = 1e-3,
    model: str = "swerling1",
) -> Array:
    """Map sensing SNR to single-observation target detection probability.

    Answers Reviewer 4, Q2 (how to interpret the reported sensing SNR in radar
    terms). Two square-law-detector models are provided:

    * ``swerling1`` (default): Rayleigh-fluctuating RCS, consistent with the
      radar-cross-section-variance target model used here. Closed form
      ``Pd = Pfa ** (1 / (1 + chi))`` with linear SNR ``chi``.
    * ``nonfluctuating`` (Swerling 0): ``Pd = Q_1(sqrt(2 chi), sqrt(-2 ln Pfa))``
      evaluated through the noncentral chi-square survival function.
    """
    chi = np.maximum(10.0 ** (np.asarray(sensing_snr_db, dtype=float) / 10.0), 0.0)
    if not 0.0 < pfa < 1.0:
        raise ValueError("pfa must be in (0, 1)")
    model = model.lower()
    if model == "swerling1":
        return pfa ** (1.0 / (1.0 + chi))
    if model == "nonfluctuating":
        from scipy.stats import ncx2
        threshold = -2.0 * np.log(pfa)
        return ncx2.sf(threshold, df=2, nc=2.0 * chi)
    raise ValueError("model must be 'swerling1' or 'nonfluctuating'")


def per_user_sinr_db(scenario: "Scenario", W: Array) -> Array:
    """Per-user SINR (dB) on the physical true channel (Reviewer 4, Q10)."""
    return sinr_db(
        scenario.h_true, W, scenario.tx_aps, scenario.normalized_noise_variance
    )


def per_user_sinr_unseen_db(
    cfg: "SystemConfig",
    scenario: "Scenario",
    csi: "CSIRealization",
    W: Array,
    n_test_errors: int,
    test_seed: int,
) -> Array:
    """Per-user SINR (dB) over unseen CSI-error draws: shape (n_test_errors, U).

    Supports the requested distribution/CDF plots across users (Reviewer 4, Q10)
    rather than only the per-user minimum.
    """
    samples = sample_csi_scenarios(
        csi, n_scenarios=n_test_errors, seed=test_seed, include_nominal=False
    )
    out = np.empty((samples.shape[0], cfg.n_users), dtype=float)
    for k in range(samples.shape[0]):
        out[k] = sinr_db(
            samples[k], W, scenario.tx_aps, scenario.normalized_noise_variance
        )
    return out


def max_sinr_constraint_violation_db(
    scenario: "Scenario", W: Array, gamma_target_db: float
) -> float:
    """Worst per-user QoS-constraint gap (dB) on the true channel.

    Non-negative; zero means every user meets the SINR target. Used to bound the
    empirical constraint violation of stored solutions (Reviewer 2, C6).
    """
    s_db = sinr_db(
        scenario.h_true, W, scenario.tx_aps, scenario.normalized_noise_variance
    )
    return float(max(0.0, gamma_target_db - float(np.min(s_db))))


def summarize_solver_reliability(raw_results: pd.DataFrame) -> pd.DataFrame:
    """Per-method solver-reliability report (Reviewer 2, C6).

    Reports, per method, the fraction of runs that hit the sweep limit, the
    fraction flagged inaccurate/failed by the solver, and iteration statistics.
    Expects the DataFrame produced by ``run_v7_methods_on_same_realization`` /
    ``run_v7_monte_carlo`` (columns ``method``, ``status``, ``iterations``).
    """
    def _frac(status_series, needle):
        s = status_series.astype(str).str.lower()
        return float((s.str.contains(needle)).mean())

    rows = []
    for method, grp in raw_results.groupby("method"):
        rows.append({
            "method": method,
            "n_runs": int(len(grp)),
            "frac_max_sweeps": _frac(grp["status"], "max_sweep"),
            "frac_inaccurate": _frac(grp["status"], "inaccurate"),
            "frac_error": _frac(grp["status"], "error"),
            "frac_converged": _frac(grp["status"], "converged"),
            "mean_iterations": float(grp["iterations"].mean())
            if "iterations" in grp else float("nan"),
            "max_iterations": float(grp["iterations"].max())
            if "iterations" in grp else float("nan"),
        })
    return pd.DataFrame(rows)


def apply_ap_phase_errors(
    h_eval: Array,
    tx_aps: Sequence[int],
    phase_std_deg: float,
    seed: int,
) -> Array:
    """Apply an independent residual carrier-phase offset to each transmit AP.

    Models imperfect inter-AP synchronization after beamformer design: the
    contribution of AP ``a`` is multiplied by exp(j*theta_a), with
    theta_a ~ N(0, (phase_std_deg*pi/180)^2), common across that AP's antennas
    and users. Evaluating a fixed beamformer on the returned channel quantifies
    the robustness framework's sensitivity to synchronization error (Reviewer 4,
    Q8). Returns a copy; the input is not modified.
    """
    rng = _rng(seed)
    h_out = np.array(h_eval, dtype=np.complex128)
    sigma = float(phase_std_deg) * np.pi / 180.0
    for a in tx_aps:
        theta = rng.normal(0.0, sigma) if sigma > 0 else 0.0
        h_out[:, :, int(a)] *= np.exp(1j * theta)
    return h_out


def summarize_metrics_with_sync_error(
    cfg: "SystemConfig",
    scenario: "Scenario",
    W: Array,
    sinr_target_db: float,
    phase_std_deg: float,
    n_draws: int = 200,
    seed: int = 0,
) -> Dict[str, float]:
    """Mean communication metrics under random per-AP phase desync (Reviewer 4, Q8)."""
    mins, means, outages = [], [], []
    for k in range(n_draws):
        h_sync = apply_ap_phase_errors(
            scenario.h_true, scenario.tx_aps, phase_std_deg, seed + k
        )
        s_db = sinr_db(h_sync, W, scenario.tx_aps, scenario.normalized_noise_variance)
        mins.append(float(np.min(s_db)))
        means.append(float(np.mean(s_db)))
        outages.append(float(np.mean(s_db < sinr_target_db)))
    return {
        "phase_std_deg": float(phase_std_deg),
        "min_sinr_db_mean": float(np.mean(mins)),
        "mean_sinr_db_mean": float(np.mean(means)),
        "user_outage_mean": float(np.mean(outages)),
        "network_outage": float(np.mean(np.array(mins) < sinr_target_db)),
    }


def run_scenario_count_sensitivity(
    cfg: "SystemConfig",
    pilot_snr_db: float,
    seeds: Sequence[int],
    train_counts: Sequence[int],
    admm: "ADMMConfig",
    v7: "V7Config",
    joint_confidence: float = 0.95,
    n_unseen_test_errors: int = 64,
    pilot_length: int = 1,
    estimator: str = "ls",
) -> pd.DataFrame:
    """Training-scenario-count sensitivity study (Reviewer 2 C2; Reviewer 4 Q5).

    For each training-scenario count, evaluates the adapted-JointOpt baseline and
    the uncertainty-aware SR-CBSA on the same seeds, so the SR-CBSA-vs-JointOpt
    gap can be reported as a function of the number of sampled scenarios.
    """
    methods = ("v6_nominal_gain_eta", "v7_scenario_global_sca_uncertainty_eta")
    frames = []
    for k in train_counts:
        v7_k = replace(v7, n_train_scenarios=int(k))
        for seed in seeds:
            frame, _ = run_v7_methods_on_same_realization(
                cfg, pilot_snr_db=float(pilot_snr_db), seed=int(seed),
                admm=admm, v7=v7_k, methods=methods,
                joint_confidence=joint_confidence,
                n_unseen_test_errors=n_unseen_test_errors,
                pilot_length=pilot_length, estimator=estimator,
            )
            frame["n_train_scenarios"] = int(k)
            frames.append(frame)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def run_scalability_sweep(
    base_cfg: "SystemConfig",
    configs: Sequence[Dict[str, int]],
    pilot_snr_db: float,
    seeds: Sequence[int],
    admm: "ADMMConfig",
    v7: "V7Config",
    methods: Sequence[str] = ("v6_nominal_gain_eta",
                              "v7_scenario_global_sca_uncertainty_eta"),
    joint_confidence: float = 0.95,
    n_unseen_test_errors: int = 64,
    pilot_length: int = 1,
    estimator: str = "ls",
) -> pd.DataFrame:
    """Scalability sweep over network size (Reviewer 2, C7).

    ``configs`` is a list of overrides, e.g.
    ``[{"n_ap":5,"n_users":3,"n_ant":3}, {"n_ap":9,"n_users":6,"n_ant":3}]``.
    Optional per-config key ``n_train_scenarios`` overrides the V7 scenario count.
    Reports communication, sensing, and runtime versus AP/user/scenario count.
    """
    frames = []
    for override in configs:
        cfg_over = {k: v for k, v in override.items() if k != "n_train_scenarios"}
        cfg = replace(base_cfg, **cfg_over)
        v7_c = v7
        if "n_train_scenarios" in override:
            v7_c = replace(v7, n_train_scenarios=int(override["n_train_scenarios"]))
        for seed in seeds:
            frame, _ = run_v7_methods_on_same_realization(
                cfg, pilot_snr_db=float(pilot_snr_db), seed=int(seed),
                admm=admm, v7=v7_c, methods=methods,
                joint_confidence=joint_confidence,
                n_unseen_test_errors=n_unseen_test_errors,
                pilot_length=pilot_length, estimator=estimator,
            )
            frame["n_ap"] = cfg.n_ap
            frame["n_users"] = cfg.n_users
            frame["n_ant"] = cfg.n_ant
            frame["n_train_scenarios"] = v7_c.n_train_scenarios
            frames.append(frame)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


# ===========================================================================
# Parallel, resumable Monte Carlo (addresses "Monte Carlo too slow to finish")
# ===========================================================================

def _mc_worker(packed):
    """Top-level worker (must be importable for multiprocessing pickling)."""
    (cfg, pilot, seed, admm, v7, methods, joint_confidence,
     n_unseen_test_errors, pilot_length, estimator) = packed
    frame, _ = run_v7_methods_on_same_realization(
        cfg, pilot_snr_db=float(pilot), seed=int(seed), admm=admm, v7=v7,
        methods=methods, joint_confidence=joint_confidence,
        n_unseen_test_errors=n_unseen_test_errors,
        pilot_length=pilot_length, estimator=estimator,
    )
    return float(pilot), int(seed), frame


def run_v7_monte_carlo_parallel(
    cfg: SystemConfig,
    pilot_snrs_db: Sequence[float],
    seeds: Sequence[int],
    admm: ADMMConfig,
    v7: V7Config,
    methods: Sequence[str],
    joint_confidence: float = 0.95,
    n_unseen_test_errors: int = 64,
    pilot_length: int = 1,
    estimator: str = "ls",
    checkpoint_csv: Optional[str | Path] = None,
    n_jobs: Optional[int] = None,
    resume: bool = True,
    progress: bool = True,
) -> pd.DataFrame:
    """Parallel drop-in for ``run_v7_monte_carlo``.

    Runs the (pilot SNR, seed) grid concurrently across ``n_jobs`` processes and
    writes ``checkpoint_csv`` after every completed task. Identical numerical
    results to the serial version (each task is deterministic in its seed); only
    the wall-clock time changes. With ``resume=True`` (default), tasks whose
    (pilot_snr_db, seed) already appear in an existing checkpoint are skipped, so
    an interrupted run continues where it stopped. ``n_jobs=None`` uses all cores.
    """
    import os
    from concurrent.futures import ProcessPoolExecutor, as_completed

    checkpoint = Path(checkpoint_csv) if checkpoint_csv else None
    existing_frames: List[pd.DataFrame] = []
    completed = set()
    if resume and checkpoint is not None and checkpoint.exists():
        prev = pd.read_csv(checkpoint)
        existing_frames.append(prev)
        if {"pilot_snr_db", "seed"}.issubset(prev.columns):
            completed = set(zip(prev["pilot_snr_db"].round(6).tolist(),
                                prev["seed"].astype(int).tolist()))

    tasks = []
    for pilot in pilot_snrs_db:
        for seed in seeds:
            if (round(float(pilot), 6), int(seed)) in completed:
                continue
            tasks.append((cfg, pilot, seed, admm, v7, methods,
                          joint_confidence, n_unseen_test_errors,
                          pilot_length, estimator))

    if n_jobs is None:
        n_jobs = max(1, min(len(tasks), (os.cpu_count() or 1)))
    if progress:
        print(f"[MC] {len(tasks)} task(s) on {n_jobs} worker(s); "
              f"{len(completed)} already in checkpoint.", flush=True)

    def _flush():
        if checkpoint is not None:
            checkpoint.parent.mkdir(parents=True, exist_ok=True)
            pd.concat(existing_frames + new_frames, ignore_index=True).to_csv(
                checkpoint, index=False)

    new_frames: List[pd.DataFrame] = []
    if tasks and n_jobs > 1:
        done = 0
        with ProcessPoolExecutor(max_workers=n_jobs) as ex:
            futures = {ex.submit(_mc_worker, t): (t[1], t[2]) for t in tasks}
            for fut in as_completed(futures):
                pilot, seed, frame = fut.result()
                new_frames.append(frame)
                done += 1
                _flush()
                if progress:
                    print(f"[MC] {done}/{len(tasks)} (pilot={pilot} dB, seed={seed})",
                          flush=True)
    elif tasks:  # serial fallback
        for k, t in enumerate(tasks, 1):
            _, _, frame = _mc_worker(t)
            new_frames.append(frame)
            _flush()
            if progress:
                print(f"[MC] {k}/{len(tasks)}", flush=True)

    all_frames = existing_frames + new_frames
    return pd.concat(all_frames, ignore_index=True) if all_frames else pd.DataFrame()
