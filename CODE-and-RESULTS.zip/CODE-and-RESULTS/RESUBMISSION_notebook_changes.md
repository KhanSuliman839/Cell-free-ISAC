# Resubmission code changes: what to do in the notebooks

The engine is one shared module (`robust_cellfree_isac_v7.py`, written by cell 5
via `%%writefile`). Replace the body of that cell (everything after the
`%%writefile robust_cellfree_isac_v7.py` line) with the updated
`robust_cellfree_isac_v7.py` provided alongside this file. All five notebooks
share that cell, so you update it once and re-paste into each, or keep the module
as a standalone `.py` and `import` it.

Every change below has been run and verified. Default arguments reproduce your
current results bit-for-bit (`h_hat`, `epsilon`, `error_variance` identical), so
nothing moves until you opt in.

--------------------------------------------------------------------------------

## 1. Config-cell fixes (all notebooks)

`RUN_SINGLE_V7` is referenced in the "Run the proposed V7 method" cell but is not
defined in the `base` and `baseline` config cells, so a clean top-to-bottom run
raises `NameError`. Add this line to the config cell of every notebook that lacks
it:

```python
RUN_SINGLE_V7 = False   # set True only in the single-V7 notebook
```

To actually produce the Monte Carlo evidence (Reviewers 1, 2, 3), set in the
config cell:

```python
RUN_MONTE_CARLO = True
PILOT_SNRS_DB   = [5, 10, 15, 20]     # complete the grid, not just 5 dB
N_MONTE_CARLO   = 100                  # or a defensible reduced count, e.g. 40
```

--------------------------------------------------------------------------------

## 2. Method lists: add the worst-case baseline, keep scenario-adapted JointOpt

The worst-case robust benchmark already exists in the module
(`centralized_robust_isac_socp`) and is now selectable as the method key
`"worstcase_robust_socp"`. Update both method tuples.

Same-realization comparison cell (`COMPARISON_METHODS`):

```python
COMPARISON_METHODS = (
    'initializer',
    'v6_nominal_gain_eta',            # adapted JointOpt
    'v6_scenario_robust_eta',         # scenario-adapted JointOpt
    'worstcase_robust_socp',          # NEW: established worst-case robust SOCP (Reviewer 3, C5)
    'v7_nominal_global_sca_gain_eta', # nominal coordinated SCA ablation
    'v7_scenario_global_sca_uniform',
    'v7_scenario_global_sca_gain_eta',
    'v7_scenario_global_sca_uncertainty_eta',
)
```

Monte Carlo cell (`MC_METHODS`) — currently omits scenario-adapted JointOpt, which
is why it vanishes from Table V while the caption says "six methods" (Reviewer 2,
C5). Add it back plus the worst-case baseline:

```python
MC_METHODS = (
    'initializer',
    'v6_nominal_gain_eta',            # adapted JointOpt
    'v6_scenario_robust_eta',         # RESTORED: scenario-adapted JointOpt
    'worstcase_robust_socp',          # NEW: worst-case robust SOCP
    'v7_nominal_global_sca_gain_eta',
    'v7_scenario_global_sca_uniform',
    'v7_scenario_global_sca_gain_eta',
    'v7_scenario_global_sca_uncertainty_eta',
)
```

`initializer` is not a reported method row; excluding it, the table now reports
the six/seven methods the caption promises. Fix the Table V caption to match the
number you actually report.

--------------------------------------------------------------------------------

## 3. Proper pilot-based CSI model (Reviewers 3 C2/tech, 4 Q1)

`estimate_csi` now implements an explicit uplink-pilot model: length-`tau_p`
orthogonal pilots, per-symbol pilot SNR `rho_p`, LS or LMMSE estimator, and the
error covariance `C_{u,a} = sigma_e^2 I` derived from them. Defaults
(`pilot_length=1, estimator='ls'`) reproduce your current stylized model exactly.

For the resubmission, use a valid orthogonal-pilot setting (`tau_p >= n_users`)
and LMMSE by passing the two new arguments straight through the runners:

```python
# same-realization
comparison, method_results = run_v7_methods_on_same_realization(
    SYSTEM, pilot_snr_db=10.0, seed=seed, admm=ADMM_BASELINE, v7=V7,
    methods=COMPARISON_METHODS, joint_confidence=JOINT_CONFIDENCE,
    n_unseen_test_errors=N_UNSEEN_TEST_ERRORS,
    pilot_length=SYSTEM.n_users, estimator='lmmse',   # <-- proper model
)

# Monte Carlo
raw_results = run_v7_monte_carlo(
    SYSTEM, pilot_snrs_db=PILOT_SNRS_DB, seeds=MC_SEEDS, admm=ADMM_BASELINE,
    v7=V7, methods=MC_METHODS, joint_confidence=JOINT_CONFIDENCE,
    n_unseen_test_errors=N_UNSEEN_TEST_ERRORS,
    pilot_length=SYSTEM.n_users, estimator='lmmse', checkpoint_csv='mc_checkpoint.csv',
)
```

IMPORTANT: switching to the proper estimator lowers CSI NMSE (about 6 dB at
`tau_p = n_users`, LMMSE) and therefore changes every reported number. This is
expected and defensible, but it means the whole evidence set must be regenerated
under the model you describe in the paper. Decide `tau_p` and estimator once,
state them in the system table, and run everything with them. The direct call in
the "generate one physical network" cell (`estimate_csi(..., pilot_snr_db=10.0)`)
should get the same two arguments so the diagnostics match the experiments.

--------------------------------------------------------------------------------

## 4. New reporting cells (paste as new cells where relevant)

### 4a. 600-dpi figures (Reviewer 1, C2)

Put this once near the top, after imports, and save figures explicitly:

```python
set_publication_style(dpi=600)
# when saving any figure:
fig.savefig('figure3.pdf')             # vector, best for line art
# or fig.savefig('figure3.png', dpi=600)
```

### 4b. Per-user SINR distribution (Reviewer 4, Q10)

```python
import numpy as np, matplotlib.pyplot as plt
W_uncert = method_results['v7_scenario_global_sca_uncertainty_eta'].W
W_nom    = method_results['v7_nominal_global_sca_gain_eta'].W

fig, ax = plt.subplots(figsize=(5, 3.2))
for W, label in [(W_nom, 'Nominal SCA'), (W_uncert, 'SR-CBSA (uncert.)')]:
    s = np.sort(per_user_sinr_unseen_db(SYSTEM, scenario, csi, W,
                                        n_test_errors=200, test_seed=seed+91_000).ravel())
    ax.plot(s, np.linspace(0, 1, s.size), label=label)
ax.axvline(SINR_TARGET_DB, ls='--', c='k', lw=1, label='QoS target')
ax.set_xlabel('Per-user SINR (dB)'); ax.set_ylabel('Empirical CDF'); ax.legend()
fig.savefig('per_user_sinr_cdf.pdf')
```

This shows that nominal SCA wins on the mean while SR-CBSA lifts the worst-user
tail, which is the intended trade behind "1.69 dB vs ~0 dB".

### 4c. Solver-reliability report (Reviewer 2, C6)

```python
reliability = summarize_solver_reliability(raw_results)   # per-method fractions
display(reliability)

# worst QoS-constraint gap on the true channel, per method/seed:
raw_results['max_constraint_violation_db'] = [
    max_sinr_constraint_violation_db(
        generate_true_scenario(SYSTEM, seed=int(r.seed)),
        method_results_for(r),   # or recompute W; see note below
        SINR_TARGET_DB)
    for r in raw_results.itertuples()
]
```

Simplest path: add the violation as a column inside the Monte Carlo loop where you
already hold each `result.W`, rather than recomputing afterward. For the
"tighter-solver verification", re-run a handful of seeds with
`V7Config(..., solver='SCS', solver_max_iters=40_000)` and confirm the outage
numbers are unchanged.

### 4d. Scenario-count sensitivity (Reviewer 2 C2, Reviewer 4 Q5)

```python
sens = run_scenario_count_sensitivity(
    SYSTEM, pilot_snr_db=5.0, seeds=MC_SEEDS[:20],
    train_counts=[4, 8, 16, 32, 64], admm=ADMM_BASELINE, v7=V7,
    n_unseen_test_errors=N_UNSEEN_TEST_ERRORS,
    pilot_length=SYSTEM.n_users, estimator='lmmse',
)
summary = (sens.groupby(['n_train_scenarios', 'method'])
              [['unseen_network_outage', 'min_sinr_db']].mean())
display(summary)
```

### 4e. Scalability sweep vs network size (Reviewer 2, C7)

```python
scal = run_scalability_sweep(
    SYSTEM,
    configs=[
        {'n_ap': 5, 'n_users': 3, 'n_ant': 3, 'n_train_scenarios': 16},
        {'n_ap': 7, 'n_users': 4, 'n_ant': 4, 'n_train_scenarios': 16},
        {'n_ap': 9, 'n_users': 6, 'n_ant': 3, 'n_train_scenarios': 16},
        {'n_ap': 12, 'n_users': 8, 'n_ant': 4, 'n_train_scenarios': 16},
    ],
    pilot_snr_db=5.0, seeds=MC_SEEDS[:5], admm=ADMM_BASELINE, v7=V7,
    pilot_length=SYSTEM.n_users, estimator='lmmse',
)
display(scal.groupby(['n_ap', 'n_users', 'n_ant'])
            [['min_sinr_db', 'sinr_outage', 'runtime_s']].mean())
```

Report runtime versus AP/user/scenario count and relate it to channel-coherence
time in the discussion.

### 4f. Sensing SNR to detection probability (Reviewer 4, Q2)

```python
for method, W in [('SR-CBSA', W_uncert), ('Worst-case SOCP', method_results['worstcase_robust_socp'].W)]:
    snr = sensing_snr_db(SYSTEM, scenario, W)
    pd_val = detection_probability(snr, pfa=1e-3, model='swerling1')
    print(method, 'sensing SNR', np.round(snr, 2), 'Pd@Pfa1e-3', np.round(pd_val, 3))
```

### 4g. Synchronization-error sensitivity (Reviewer 4, Q8)

```python
sync_rows = [summarize_metrics_with_sync_error(SYSTEM, scenario, W_uncert,
                                                SINR_TARGET_DB, phase_std_deg=p,
                                                n_draws=200, seed=7)
             for p in [0, 2, 5, 10, 15, 20]]
display(pd.DataFrame(sync_rows))
```

--------------------------------------------------------------------------------

## Reviewer-comment coverage (code side)

Resolved in the updated module / cells above:
- R1.2 600-dpi export — `set_publication_style`.
- R2.5 Table V method count / restored scenario-adapted JointOpt — `MC_METHODS`.
- R3.5 established worst-case robust baseline — `worstcase_robust_socp` wired in.
- R2.6 solver reliability — `summarize_solver_reliability`, `max_sinr_constraint_violation_db`.
- R4.10 per-user SINR distribution — `per_user_sinr_db`, `per_user_sinr_unseen_db`.
- R4.2 detection probability — `detection_probability`.
- R4.8 synchronization error — `apply_ap_phase_errors`, `summarize_metrics_with_sync_error`.
- R2.2 / R4.5 scenario-count sensitivity — `run_scenario_count_sensitivity`.
- R2.7 scalability sweep — `run_scalability_sweep`.
- R3.2 / R4.1 explicit pilot/estimator model — `estimate_csi(pilot_length, estimator)`.

Requires only running (no further code): R1.3 / R2.1 / R3.1 complete Monte Carlo
across 5/10/15/20 dB.

Still manuscript text, not code: R1.1 draft marks, R1.5 full subproblem math,
R2.3 / R1.4 CRB relabeling, R3.3 report existing tolerances/stopping criteria,
R3.4 scenario-guarantee wording, R3.5 reference cleanup, R4.3 convergence
analysis, R4.7 damping-vs-trust-region justification, R4.9 baseline description,
novelty framing.

--------------------------------------------------------------------------------

## UPDATE (supersedes the estimator default above)

Two corrections after test runs:

1. Estimator default reverted. The notebooks now ship with `PILOT_LENGTH = 1`
   and `ESTIMATOR = 'ls'`, which reproduce the paper's original CSI NMSE and
   operating regime exactly. The earlier `lmmse` + `tau_p = n_users` default made
   CSI about 8 dB more accurate (NMSE -18 dB vs -10 dB at 10 dB pilot SNR), which
   quietly weakened the imperfect-CSI premise and the headline outage result.
   The LMMSE / multi-pilot model is still available as an optional estimator-
   quality study; it is just no longer the default. Reviewers 3 and 4 asked for
   the pilot model to be defined and reproducible, not for a cleaner operating
   point, so `ls` / `tau_p = 1` with the model written out in the manuscript is
   the right answer.

2. Parallel, resumable Monte Carlo (fixes "too slow / won't finish"). The MC cell
   now calls `run_v7_monte_carlo_parallel`, which runs the (pilot SNR, seed) grid
   across `N_JOBS` worker processes, writes the checkpoint after every completed
   task, and skips tasks already in the checkpoint on resume. Results are
   numerically identical to the serial version (verified); only wall-clock time
   changes. To actually finish the grid:
   - Run on a multi-core machine (the speedup is roughly proportional to cores;
     on 1-2 cores it barely helps). Set `N_JOBS = None` to use all cores.
   - A single-thread-BLAS header now runs before numpy is imported, so the worker
     processes do not oversubscribe cores.
   - `N_MONTE_CARLO` defaults to 40 (a defensible subset); raise to 100 for the
     full grid, or run one SNR at a time via `PILOT_SNRS_DB` and combine the
     checkpoint CSVs.
   - If a run is interrupted, just re-run the cell; it resumes from the checkpoint.
